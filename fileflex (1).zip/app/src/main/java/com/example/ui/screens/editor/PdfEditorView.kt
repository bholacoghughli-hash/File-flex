package com.example.ui.screens.editor

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color as AndroidColor
import android.graphics.RectF
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.CropSquare
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Draw
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Highlight
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MergeType
import androidx.compose.material.icons.filled.NavigateBefore
import androidx.compose.material.icons.filled.NavigateNext
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Redo
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.AnnotationType
import com.example.engine.PdfEditEngine
import com.example.engine.PdfPageAnnotation
import com.example.engine.PdfPageSpec
import com.example.localization.AppLanguage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

enum class PdfEditorTool {
    VIEW,
    PEN,
    HIGHLIGHT,
    TEXT,
    SHAPE,
    SIGNATURE
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun PdfEditorView(
    initialUri: Uri?,
    initialFileName: String,
    language: AppLanguage,
    onSaveToWorkspace: (File, String) -> Unit,
    onOpenFile: (File) -> Unit,
    onShareFile: (File) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var activeLocalPdf by remember { mutableStateOf<File?>(null) }
    var fileName by remember { mutableStateOf(initialFileName.ifBlank { "document.pdf" }) }
    var pageCount by remember { mutableIntStateOf(0) }
    var currentPageIndex by remember { mutableIntStateOf(0) }
    var currentPageBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var isLoading by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf("") }

    val pageSpecs = remember { mutableStateListOf<PdfPageSpec>() }
    val annotations = remember { mutableStateListOf<PdfPageAnnotation>() }

    var selectedTool by remember { mutableStateOf(PdfEditorTool.VIEW) }
    var penColor by remember { mutableStateOf(Color(0xFF2563EB)) }
    var penStrokeWidth by remember { mutableStateOf(6f) }

    // Dialogs
    var showAddTextDialog by remember { mutableStateOf(false) }
    var textToAdd by remember { mutableStateOf("") }
    var showSignatureDialog by remember { mutableStateOf(false) }
    var showExportMenu by remember { mutableStateOf(false) }
    var showToolsSheet by remember { mutableStateOf(false) }
    var exportedFile by remember { mutableStateOf<File?>(null) }

    // File pickers
    val openPdfLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            scope.launch {
                isLoading = true
                statusMessage = "Loading PDF..."
                try {
                    val local = withContext(Dispatchers.IO) {
                        PdfEditEngine.copyUriToLocalCache(context, it)
                    }
                    activeLocalPdf = local
                    fileName = "edited_${System.currentTimeMillis()}.pdf"
                    val count = withContext(Dispatchers.IO) { PdfEditEngine.getPageCount(local) }
                    pageCount = count
                    pageSpecs.clear()
                    annotations.clear()
                    for (i in 0 until count) {
                        pageSpecs.add(PdfPageSpec(originalPageIndex = i))
                    }
                    currentPageIndex = 0
                    val bmp = withContext(Dispatchers.IO) {
                        PdfEditEngine.renderPageToBitmap(local, 0)
                    }
                    currentPageBitmap = bmp
                } catch (e: Exception) {
                    statusMessage = "Failed to load PDF: ${e.message}"
                } finally {
                    isLoading = false
                }
            }
        }
    }

    // Merge pickers
    val mergePdfLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris: List<Uri> ->
        if (uris.size >= 2) {
            scope.launch {
                isLoading = true
                statusMessage = "Merging ${uris.size} PDFs..."
                try {
                    val tempFiles = withContext(Dispatchers.IO) {
                        uris.map { PdfEditEngine.copyUriToLocalCache(context, it) }
                    }
                    val outFile = File(context.cacheDir, "merged_${System.currentTimeMillis()}.pdf")
                    val merged = withContext(Dispatchers.IO) {
                        PdfEditEngine.mergePdfs(tempFiles, outFile) {}
                    }
                    activeLocalPdf = merged
                    fileName = outFile.name
                    val count = withContext(Dispatchers.IO) { PdfEditEngine.getPageCount(merged) }
                    pageCount = count
                    pageSpecs.clear()
                    annotations.clear()
                    for (i in 0 until count) {
                        pageSpecs.add(PdfPageSpec(originalPageIndex = i))
                    }
                    currentPageIndex = 0
                    currentPageBitmap = withContext(Dispatchers.IO) {
                        PdfEditEngine.renderPageToBitmap(merged, 0)
                    }
                    onSaveToWorkspace(merged, "PDF")
                } catch (e: Exception) {
                    statusMessage = "Merge failed: ${e.message}"
                } finally {
                    isLoading = false
                }
            }
        }
    }

    // Load initial file if provided
    LaunchedEffect(initialUri) {
        if (initialUri != null && activeLocalPdf == null) {
            isLoading = true
            statusMessage = "Loading PDF..."
            try {
                val local = withContext(Dispatchers.IO) {
                    PdfEditEngine.copyUriToLocalCache(context, initialUri)
                }
                activeLocalPdf = local
                val count = withContext(Dispatchers.IO) { PdfEditEngine.getPageCount(local) }
                pageCount = count
                pageSpecs.clear()
                annotations.clear()
                for (i in 0 until count) {
                    pageSpecs.add(PdfPageSpec(originalPageIndex = i))
                }
                currentPageIndex = 0
                currentPageBitmap = withContext(Dispatchers.IO) {
                    PdfEditEngine.renderPageToBitmap(local, 0)
                }
            } catch (e: Exception) {
                statusMessage = "Could not open initial PDF"
            } finally {
                isLoading = false
            }
        }
    }

    // Refresh current page bitmap when pageIndex or rotation changes
    fun refreshCurrentPage(pageIdx: Int) {
        val pdf = activeLocalPdf ?: return
        if (pageIdx !in 0 until pageSpecs.size) return
        scope.launch {
            val spec = pageSpecs[pageIdx]
            val bmp = withContext(Dispatchers.IO) {
                PdfEditEngine.renderPageToBitmap(
                    pdfFile = pdf,
                    pageIndex = spec.originalPageIndex,
                    rotationDegrees = spec.rotationDegrees
                )
            }
            currentPageBitmap = bmp
        }
    }

    // Save edited PDF
    fun saveEditedPdf() {
        val pdf = activeLocalPdf ?: return
        scope.launch {
            isLoading = true
            statusMessage = "Exporting edited PDF..."
            try {
                val outFile = File(context.cacheDir, "edited_${System.currentTimeMillis()}.pdf")
                val exported = PdfEditEngine.exportEditedPdf(
                    pdfFile = pdf,
                    pageSpecs = pageSpecs.toList(),
                    annotations = annotations.toList(),
                    outputFile = outFile,
                    onProgress = { p -> statusMessage = "Exporting PDF (${(p * 100).toInt()}%)" }
                )
                exportedFile = exported
                onSaveToWorkspace(exported, "PDF")
                statusMessage = "PDF saved successfully!"
            } catch (e: Exception) {
                statusMessage = "Export failed: ${e.message}"
            } finally {
                isLoading = false
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Top Toolbar
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 2.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.PictureAsPdf,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = fileName,
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            maxLines = 1
                        )
                        Text(
                            text = if (pageCount > 0) "Page ${currentPageIndex + 1} of ${pageSpecs.filter { !it.isDeleted }.size}" else "No document loaded",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Button(
                        onClick = { openPdfLauncher.launch(arrayOf("application/pdf")) },
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Open PDF", fontSize = 12.sp)
                    }
                    if (activeLocalPdf != null) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Button(
                            onClick = { saveEditedPdf() },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Save", fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        if (activeLocalPdf == null) {
            // Empty State / Welcome to PDF Editor
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                ElevatedCard(
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PictureAsPdf,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Professional PDF Editor",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Annotate, draw, sign, add text, reorder, rotate, split, merge, and convert PDFs directly on your device.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = { openPdfLauncher.launch(arrayOf("application/pdf")) },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("Open PDF to Edit")
                            }
                            OutlinedButton(
                                onClick = { mergePdfLauncher.launch(arrayOf("application/pdf")) },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.MergeType, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Merge PDFs")
                            }
                        }
                    }
                }
            }
        } else {
            // PDF Editing Workspace
            // Tool selection strip
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            ) {
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    item {
                        FilterChip(
                            selected = selectedTool == PdfEditorTool.VIEW,
                            onClick = { selectedTool = PdfEditorTool.VIEW },
                            label = { Text("Pan / View") }
                        )
                    }
                    item {
                        FilterChip(
                            selected = selectedTool == PdfEditorTool.PEN,
                            onClick = { selectedTool = PdfEditorTool.PEN },
                            leadingIcon = { Icon(Icons.Default.Draw, contentDescription = null, modifier = Modifier.size(16.dp)) },
                            label = { Text("Draw") }
                        )
                    }
                    item {
                        FilterChip(
                            selected = selectedTool == PdfEditorTool.HIGHLIGHT,
                            onClick = { selectedTool = PdfEditorTool.HIGHLIGHT },
                            leadingIcon = { Icon(Icons.Default.Highlight, contentDescription = null, modifier = Modifier.size(16.dp)) },
                            label = { Text("Highlight") }
                        )
                    }
                    item {
                        FilterChip(
                            selected = selectedTool == PdfEditorTool.TEXT,
                            onClick = {
                                selectedTool = PdfEditorTool.TEXT
                                showAddTextDialog = true
                            },
                            leadingIcon = { Icon(Icons.Default.TextFields, contentDescription = null, modifier = Modifier.size(16.dp)) },
                            label = { Text("Add Text") }
                        )
                    }
                    item {
                        FilterChip(
                            selected = selectedTool == PdfEditorTool.SIGNATURE,
                            onClick = {
                                selectedTool = PdfEditorTool.SIGNATURE
                                showSignatureDialog = true
                            },
                            leadingIcon = { Icon(Icons.Default.Brush, contentDescription = null, modifier = Modifier.size(16.dp)) },
                            label = { Text("Signature") }
                        )
                    }
                    item {
                        FilterChip(
                            selected = selectedTool == PdfEditorTool.SHAPE,
                            onClick = {
                                val newAnnot = PdfPageAnnotation(
                                    pageIndex = currentPageIndex,
                                    type = AnnotationType.RECTANGLE,
                                    color = penColor.toArgb(),
                                    strokeWidth = penStrokeWidth,
                                    rect = RectF(100f, 100f, 400f, 300f)
                                )
                                annotations.add(newAnnot)
                            },
                            leadingIcon = { Icon(Icons.Default.CropSquare, contentDescription = null, modifier = Modifier.size(16.dp)) },
                            label = { Text("Rectangle") }
                        )
                    }
                    item {
                        OutlinedButton(
                            onClick = { showToolsSheet = true },
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text("Page & Export Tools", fontSize = 12.sp)
                        }
                    }
                }
            }

            // Interactive PDF Page Canvas
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .background(Color(0xFFE2E8F0))
                    .padding(12.dp),
                contentAlignment = Alignment.Center
            ) {
                if (isLoading) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(modifier = Modifier.size(36.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(statusMessage, style = MaterialTheme.typography.bodySmall)
                    }
                } else if (currentPageBitmap != null) {
                    val bmp = currentPageBitmap!!
                    val activeStroke = remember { mutableStateListOf<Pair<Float, Float>>() }

                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color.White)
                            .pointerInput(selectedTool) {
                                if (selectedTool == PdfEditorTool.PEN || selectedTool == PdfEditorTool.HIGHLIGHT) {
                                    detectDragGestures(
                                        onDragStart = { offset ->
                                            activeStroke.clear()
                                            activeStroke.add(Pair(offset.x, offset.y))
                                        },
                                        onDrag = { change, _ ->
                                            change.consume()
                                            activeStroke.add(Pair(change.position.x, change.position.y))
                                        },
                                        onDragEnd = {
                                            if (activeStroke.size > 1) {
                                                val type = if (selectedTool == PdfEditorTool.HIGHLIGHT) AnnotationType.HIGHLIGHT else AnnotationType.DRAWING
                                                val color = if (selectedTool == PdfEditorTool.HIGHLIGHT) AndroidColor.YELLOW else penColor.toArgb()
                                                val width = if (selectedTool == PdfEditorTool.HIGHLIGHT) 24f else penStrokeWidth
                                                annotations.add(
                                                    PdfPageAnnotation(
                                                        pageIndex = currentPageIndex,
                                                        type = type,
                                                        color = color,
                                                        strokeWidth = width,
                                                        points = activeStroke.toList()
                                                    )
                                                )
                                            }
                                            activeStroke.clear()
                                        }
                                    )
                                }
                            }
                    ) {
                        Image(
                            bitmap = bmp.asImageBitmap(),
                            contentDescription = "PDF Page ${currentPageIndex + 1}",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Fit
                        )

                        // Annotation Overlay Canvas
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            // Render saved annotations for this page
                            val pageAnnots = annotations.filter { it.pageIndex == currentPageIndex }
                            for (annot in pageAnnots) {
                                when (annot.type) {
                                    AnnotationType.DRAWING, AnnotationType.SIGNATURE -> {
                                        if (annot.points.size > 1) {
                                            for (i in 0 until annot.points.size - 1) {
                                                drawLine(
                                                    color = Color(annot.color),
                                                    start = Offset(annot.points[i].first, annot.points[i].second),
                                                    end = Offset(annot.points[i + 1].first, annot.points[i + 1].second),
                                                    strokeWidth = annot.strokeWidth
                                                )
                                            }
                                        }
                                    }
                                    AnnotationType.HIGHLIGHT -> {
                                        if (annot.points.size > 1) {
                                            for (i in 0 until annot.points.size - 1) {
                                                drawLine(
                                                    color = Color(annot.color).copy(alpha = 0.4f),
                                                    start = Offset(annot.points[i].first, annot.points[i].second),
                                                    end = Offset(annot.points[i + 1].first, annot.points[i + 1].second),
                                                    strokeWidth = annot.strokeWidth
                                                )
                                            }
                                        }
                                    }
                                    AnnotationType.RECTANGLE -> {
                                        annot.rect?.let { r ->
                                            drawRect(
                                                color = Color(annot.color),
                                                topLeft = Offset(r.left, r.top),
                                                size = androidx.compose.ui.geometry.Size(r.width(), r.height()),
                                                style = androidx.compose.ui.graphics.drawscope.Stroke(width = annot.strokeWidth)
                                            )
                                        }
                                    }
                                    AnnotationType.TEXT -> {
                                        // Note: text handled by Compose UI text or baked on export
                                    }
                                }
                            }

                            // Render currently dragging stroke
                            if (activeStroke.size > 1) {
                                val strokeColor = if (selectedTool == PdfEditorTool.HIGHLIGHT) Color.Yellow.copy(alpha = 0.5f) else penColor
                                val strokeW = if (selectedTool == PdfEditorTool.HIGHLIGHT) 24f else penStrokeWidth
                                for (i in 0 until activeStroke.size - 1) {
                                    drawLine(
                                        color = strokeColor,
                                        start = Offset(activeStroke[i].first, activeStroke[i].second),
                                        end = Offset(activeStroke[i + 1].first, activeStroke[i + 1].second),
                                        strokeWidth = strokeW
                                    )
                                }
                            }
                        }

                        // Text annotations on screen
                        val textAnnots = annotations.filter { it.pageIndex == currentPageIndex && it.type == AnnotationType.TEXT }
                        for (txt in textAnnots) {
                            Box(
                                modifier = Modifier
                                    .padding(start = txt.x.dp, top = txt.y.dp)
                                    .background(Color.White.copy(alpha = 0.85f), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = txt.text,
                                    fontSize = txt.textSize.sp,
                                    color = Color(txt.color),
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
            }

            // Bottom Page Navigation & Thumbnails
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 3.dp
            ) {
                Column(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                    // Page control buttons
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        IconButton(
                            onClick = {
                                if (currentPageIndex > 0) {
                                    currentPageIndex--
                                    refreshCurrentPage(currentPageIndex)
                                }
                            },
                            enabled = currentPageIndex > 0
                        ) {
                            Icon(Icons.Default.NavigateBefore, contentDescription = "Previous Page")
                        }

                        Text(
                            text = "Page ${currentPageIndex + 1} of ${pageSpecs.size}",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                        )

                        IconButton(
                            onClick = {
                                if (currentPageIndex < pageSpecs.size - 1) {
                                    currentPageIndex++
                                    refreshCurrentPage(currentPageIndex)
                                }
                            },
                            enabled = currentPageIndex < pageSpecs.size - 1
                        ) {
                            Icon(Icons.Default.NavigateNext, contentDescription = "Next Page")
                        }
                    }

                    // Thumbnail row
                    LazyRow(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        itemsIndexed(pageSpecs) { idx, spec ->
                            val isSelected = idx == currentPageIndex
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                                border = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null,
                                modifier = Modifier
                                    .width(50.dp)
                                    .height(65.dp)
                                    .clickable {
                                        currentPageIndex = idx
                                        refreshCurrentPage(idx)
                                    }
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = "${idx + 1}",
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Modal Bottom Sheet: Page Tools & Export Tools
    if (showToolsSheet && activeLocalPdf != null) {
        val sheetState = rememberModalBottomSheetState()
        ModalBottomSheet(
            onDismissRequest = { showToolsSheet = false },
            sheetState = sheetState
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "Page Operations",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Spacer(modifier = Modifier.height(10.dp))

                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Rotate Page
                    OutlinedButton(
                        onClick = {
                            if (currentPageIndex in pageSpecs.indices) {
                                val current = pageSpecs[currentPageIndex]
                                pageSpecs[currentPageIndex] = current.copy(rotationDegrees = (current.rotationDegrees + 90) % 360)
                                refreshCurrentPage(currentPageIndex)
                            }
                        }
                    ) {
                        Icon(Icons.Default.RotateRight, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Rotate 90°")
                    }

                    // Duplicate Page
                    OutlinedButton(
                        onClick = {
                            if (currentPageIndex in pageSpecs.indices) {
                                val current = pageSpecs[currentPageIndex]
                                pageSpecs.add(currentPageIndex + 1, current.copy())
                                currentPageIndex++
                                refreshCurrentPage(currentPageIndex)
                            }
                        }
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Duplicate")
                    }

                    // Delete Page
                    OutlinedButton(
                        onClick = {
                            if (pageSpecs.size > 1 && currentPageIndex in pageSpecs.indices) {
                                pageSpecs.removeAt(currentPageIndex)
                                if (currentPageIndex >= pageSpecs.size) currentPageIndex = pageSpecs.size - 1
                                refreshCurrentPage(currentPageIndex)
                            }
                        },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Delete Page")
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))
                Text(
                    text = "PDF Convert & Export Tools",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Spacer(modifier = Modifier.height(10.dp))

                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // PDF to JPG
                    Button(
                        onClick = {
                            val pdf = activeLocalPdf ?: return@Button
                            scope.launch {
                                isLoading = true
                                statusMessage = "Extracting pages to JPG..."
                                try {
                                    val images = PdfEditEngine.exportPagesAsImages(
                                        pdfFile = pdf,
                                        format = "jpg",
                                        destinationDir = context.cacheDir,
                                        baseName = "page",
                                        onProgress = { p -> statusMessage = "Extracting JPGs (${(p * 100).toInt()}%)" }
                                    )
                                    images.firstOrNull()?.let { onSaveToWorkspace(it, "IMAGE") }
                                    statusMessage = "Exported ${images.size} pages as JPG"
                                } catch (e: Exception) {
                                    statusMessage = "Export failed: ${e.message}"
                                } finally {
                                    isLoading = false
                                    showToolsSheet = false
                                }
                            }
                        }
                    ) {
                        Text("PDF → JPG Images")
                    }

                    // PDF to PNG
                    OutlinedButton(
                        onClick = {
                            val pdf = activeLocalPdf
                            if (pdf != null) {
                                scope.launch {
                                    isLoading = true
                                    statusMessage = "Extracting pages to PNG..."
                                    try {
                                        val images = PdfEditEngine.exportPagesAsImages(
                                            pdfFile = pdf,
                                            format = "png",
                                            destinationDir = context.cacheDir,
                                            baseName = "page",
                                            onProgress = { p -> statusMessage = "Extracting PNGs (${(p * 100).toInt()}%)" }
                                        )
                                        images.firstOrNull()?.let { onSaveToWorkspace(it, "IMAGE") }
                                        statusMessage = "Exported ${images.size} pages as PNG"
                                    } catch (e: Exception) {
                                        statusMessage = "Export failed: ${e.message}"
                                    } finally {
                                        isLoading = false
                                        showToolsSheet = false
                                    }
                                }
                            }
                        }
                    ) {
                        Text("PDF → PNG Images")
                    }

                    // Split / Extract Single Page
                    OutlinedButton(
                        onClick = {
                            val pdf = activeLocalPdf
                            if (pdf != null) {
                                scope.launch {
                                    isLoading = true
                                    statusMessage = "Extracting page ${currentPageIndex + 1} to new PDF..."
                                    try {
                                        val out = File(context.cacheDir, "page_${currentPageIndex + 1}_${System.currentTimeMillis()}.pdf")
                                        val extracted = PdfEditEngine.extractPagesToPdf(
                                            pdfFile = pdf,
                                            pagesToExtract = listOf(currentPageIndex),
                                            outputFile = out,
                                            onProgress = {}
                                        )
                                        onSaveToWorkspace(extracted, "PDF")
                                        statusMessage = "Page extracted to ${out.name}"
                                    } catch (e: Exception) {
                                        statusMessage = "Extraction failed: ${e.message}"
                                    } finally {
                                        isLoading = false
                                        showToolsSheet = false
                                    }
                                }
                            }
                        }
                    ) {
                        Text("Extract Current Page as PDF")
                    }
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    // Add Text Dialog
    if (showAddTextDialog) {
        AlertDialog(
            onDismissRequest = { showAddTextDialog = false },
            title = { Text("Add Text to PDF") },
            text = {
                Column {
                    OutlinedTextField(
                        value = textToAdd,
                        onValueChange = { textToAdd = it },
                        label = { Text("Enter text to stamp on page") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Text will be placed at the center of the current page.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (textToAdd.isNotBlank()) {
                            annotations.add(
                                PdfPageAnnotation(
                                    pageIndex = currentPageIndex,
                                    type = AnnotationType.TEXT,
                                    text = textToAdd,
                                    color = penColor.toArgb(),
                                    textSize = 20f,
                                    x = 100f,
                                    y = 200f
                                )
                            )
                            textToAdd = ""
                            showAddTextDialog = false
                        }
                    }
                ) {
                    Text("Add Text")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddTextDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Signature Pad Dialog
    if (showSignatureDialog) {
        val signaturePoints = remember { mutableStateListOf<Pair<Float, Float>>() }
        AlertDialog(
            onDismissRequest = { showSignatureDialog = false },
            title = { Text("Draw Signature") },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text("Use your finger to draw your signature below:", style = MaterialTheme.typography.bodySmall)
                    Spacer(modifier = Modifier.height(8.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.White)
                            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                            .pointerInput(Unit) {
                                detectDragGestures(
                                    onDragStart = { offset ->
                                        signaturePoints.add(Pair(offset.x, offset.y))
                                    },
                                    onDrag = { change, _ ->
                                        change.consume()
                                        signaturePoints.add(Pair(change.position.x, change.position.y))
                                    }
                                )
                            }
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            if (signaturePoints.size > 1) {
                                for (i in 0 until signaturePoints.size - 1) {
                                    drawLine(
                                        color = Color.Black,
                                        start = Offset(signaturePoints[i].first, signaturePoints[i].second),
                                        end = Offset(signaturePoints[i + 1].first, signaturePoints[i + 1].second),
                                        strokeWidth = 5f
                                    )
                                }
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { signaturePoints.clear() }) {
                            Text("Clear Signature")
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (signaturePoints.size > 1) {
                            annotations.add(
                                PdfPageAnnotation(
                                    pageIndex = currentPageIndex,
                                    type = AnnotationType.SIGNATURE,
                                    color = AndroidColor.BLACK,
                                    strokeWidth = 4f,
                                    points = signaturePoints.toList()
                                )
                            )
                        }
                        showSignatureDialog = false
                    }
                ) {
                    Text("Apply to Page")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSignatureDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Success Dialog after Saving PDF
    if (exportedFile != null) {
        val file = exportedFile!!
        AlertDialog(
            onDismissRequest = { exportedFile = null },
            icon = { Icon(Icons.Default.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
            title = { Text("PDF Saved Successfully") },
            text = {
                Column {
                    Text("File: ${file.name}")
                    Text("Size: ${(file.length() / 1024)} KB")
                    Text("The edited PDF has been saved and added to your workspace.")
                }
            },
            confirmButton = {
                Button(onClick = { onOpenFile(file) }) {
                    Text("Open PDF")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { onShareFile(file) }) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Share")
                }
            }
        )
    }
}
