package com.example.ui.screens.editor

import android.content.Context
import android.media.MediaPlayer
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.AudioEditEngine
import com.example.engine.AudioEditParams
import com.example.localization.AppLanguage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun AudioEditorView(
    initialUri: Uri?,
    initialFileName: String,
    language: AppLanguage,
    onSaveToWorkspace: (File, String) -> Unit,
    onOpenFile: (File) -> Unit,
    onShareFile: (File) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var activeAudioUri by remember { mutableStateOf<Uri?>(initialUri) }
    var fileName by remember { mutableStateOf(initialFileName.ifBlank { "audio_track.wav" }) }
    var totalDurationMs by remember { mutableLongStateOf(0L) }
    var currentPlaybackMs by remember { mutableLongStateOf(0L) }
    var isPlaying by remember { mutableStateOf(false) }

    // Trim controls
    var trimStartSec by remember { mutableFloatStateOf(0f) }
    var trimEndSec by remember { mutableFloatStateOf(0f) }
    var volumeGain by remember { mutableFloatStateOf(1.0f) } // 0.5x to 2.0x
    var fadeIn by remember { mutableStateOf(false) }
    var fadeOut by remember { mutableStateOf(false) }

    var isLoading by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf("") }
    var exportedFile by remember { mutableStateOf<File?>(null) }

    val mediaPlayer = remember { MediaPlayer() }

    DisposableEffect(Unit) {
        onDispose {
            try {
                mediaPlayer.stop()
                mediaPlayer.release()
            } catch (_: Exception) {}
        }
    }

    // Audio file picker
    val audioPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            activeAudioUri = it
            fileName = "audio_${System.currentTimeMillis()}.wav"
            try {
                mediaPlayer.reset()
                mediaPlayer.setDataSource(context, it)
                mediaPlayer.prepare()
                val dur = mediaPlayer.duration.toLong()
                totalDurationMs = dur
                trimStartSec = 0f
                trimEndSec = (dur / 1000f).coerceAtLeast(0f)
                isPlaying = false
            } catch (e: Exception) {
                statusMessage = "Could not play audio: ${e.message}"
            }
        }
    }

    // Initial setup if initialUri provided
    LaunchedEffect(initialUri) {
        if (initialUri != null) {
            try {
                mediaPlayer.reset()
                mediaPlayer.setDataSource(context, initialUri)
                mediaPlayer.prepare()
                val dur = mediaPlayer.duration.toLong()
                totalDurationMs = dur
                trimStartSec = 0f
                trimEndSec = (dur / 1000f).coerceAtLeast(0f)
            } catch (_: Exception) {}
        }
    }

    // Playback progress ticker
    LaunchedEffect(isPlaying) {
        while (isPlaying) {
            try {
                currentPlaybackMs = mediaPlayer.currentPosition.toLong()
                if (!mediaPlayer.isPlaying) {
                    isPlaying = false
                }
            } catch (_: Exception) {}
            delay(200)
        }
    }

    fun togglePlayback() {
        try {
            if (isPlaying) {
                mediaPlayer.pause()
                isPlaying = false
            } else {
                val startMs = (trimStartSec * 1000).toInt()
                if (mediaPlayer.currentPosition < startMs || mediaPlayer.currentPosition >= (trimEndSec * 1000).toInt()) {
                    mediaPlayer.seekTo(startMs)
                }
                mediaPlayer.start()
                isPlaying = true
            }
        } catch (_: Exception) {}
    }

    fun executeTrimAndExport() {
        val uri = activeAudioUri ?: return
        scope.launch {
            isLoading = true
            statusMessage = "Trimming and processing audio..."
            try {
                val outFile = File(context.cacheDir, "trimmed_${System.currentTimeMillis()}.wav")
                val params = AudioEditParams(
                    startMs = (trimStartSec * 1000L).toLong(),
                    endMs = (trimEndSec * 1000L).toLong(),
                    volumeMultiplier = volumeGain,
                    fadeIn = fadeIn,
                    fadeOut = fadeOut,
                    exportFormat = "wav"
                )

                val result = AudioEditEngine.trimAndProcessAudio(
                    context = context,
                    inputUri = uri,
                    params = params,
                    outputFile = outFile,
                    onProgress = { p -> statusMessage = "Processing Audio (${(p * 100).toInt()}%)" }
                )

                exportedFile = result
                onSaveToWorkspace(result, "AUDIO")
                statusMessage = "Audio trimmed and saved successfully!"
            } catch (e: Exception) {
                statusMessage = "Processing failed: ${e.message}"
            } finally {
                isLoading = false
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Header
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 2.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Audiotrack,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.tertiary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = fileName,
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            maxLines = 1
                        )
                        Text(
                            text = String.format("Duration: %.1fs • %.1fx Gain", totalDurationMs / 1000f, volumeGain),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Button(
                        onClick = { audioPickerLauncher.launch("audio/*") },
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text("Open Audio", fontSize = 12.sp)
                    }
                    if (activeAudioUri != null) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Button(
                            onClick = { executeTrimAndExport() },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Save", fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        if (activeAudioUri == null) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                ElevatedCard(
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.tertiaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Audiotrack,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.tertiary,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Audio Cutter & Volume Booster",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Trim audio, cut unwanted segments, amplify volume up to 200%, add fade-in / fade-out, and export clean WAV / PCM files 100% locally.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        Button(
                            onClick = { audioPickerLauncher.launch("audio/*") },
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Select Audio File to Edit")
                        }
                    }
                }
            }
        } else {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
            ) {
                // Waveform Graphic Card & Playback Controls
                ElevatedCard(
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Animated / Simulated Waveform Bars
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(60.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                .padding(horizontal = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val barHeights = listOf(20, 35, 50, 25, 45, 60, 30, 55, 40, 20, 48, 56, 34, 22, 45, 50, 38, 25, 42, 58, 28)
                            barHeights.forEachIndexed { i, h ->
                                val active = (currentPlaybackMs.toFloat() / totalDurationMs.coerceAtLeast(1).toFloat()) >= (i.toFloat() / barHeights.size.toFloat())
                                Box(
                                    modifier = Modifier
                                        .width(6.dp)
                                        .height(h.dp)
                                        .clip(RoundedCornerShape(3.dp))
                                        .background(if (active) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Play / Pause Button & Time
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = String.format("%02d:%02d", (currentPlaybackMs / 1000) / 60, (currentPlaybackMs / 1000) % 60),
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )

                            IconButton(
                                onClick = { togglePlayback() },
                                modifier = Modifier
                                    .size(54.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.tertiary)
                            ) {
                                Icon(
                                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = if (isPlaying) "Pause" else "Play",
                                    tint = Color.White,
                                    modifier = Modifier.size(32.dp)
                                )
                            }

                            Text(
                                text = String.format("%02d:%02d", (totalDurationMs / 1000) / 60, (totalDurationMs / 1000) % 60),
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Trim & Cut Sliders Card
                ElevatedCard(
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp)
                    ) {
                        Text(
                            text = "Trim Audio Range",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        val maxSec = (totalDurationMs / 1000f).coerceAtLeast(1f)

                        Text(
                            text = String.format("Start Cut: %.1fs", trimStartSec),
                            style = MaterialTheme.typography.labelSmall
                        )
                        Slider(
                            value = trimStartSec,
                            onValueChange = { trimStartSec = it.coerceAtMost(trimEndSec - 0.5f) },
                            valueRange = 0f..maxSec
                        )

                        Text(
                            text = String.format("End Cut: %.1fs (Segment Duration: %.1fs)", trimEndSec, (trimEndSec - trimStartSec).coerceAtLeast(0f)),
                            style = MaterialTheme.typography.labelSmall
                        )
                        Slider(
                            value = trimEndSec,
                            onValueChange = { trimEndSec = it.coerceAtLeast(trimStartSec + 0.5f) },
                            valueRange = 0f..maxSec
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Effects & Volume Gain Card
                ElevatedCard(
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp)
                    ) {
                        Text(
                            text = "Audio Volume & Fades",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = String.format("Volume Gain: %.1fx (%d%%)", volumeGain, (volumeGain * 100).toInt()),
                            style = MaterialTheme.typography.labelSmall
                        )
                        Slider(
                            value = volumeGain,
                            onValueChange = { volumeGain = it },
                            valueRange = 0.5f..2.0f
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = fadeIn,
                                onClick = { fadeIn = !fadeIn },
                                label = { Text("Fade In (1.5s)") }
                            )
                            FilterChip(
                                selected = fadeOut,
                                onClick = { fadeOut = !fadeOut },
                                label = { Text("Fade Out (1.5s)") }
                            )
                        }
                    }
                }

                if (isLoading) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(statusMessage, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }

    // Success Dialog
    if (exportedFile != null) {
        val file = exportedFile!!
        AlertDialog(
            onDismissRequest = { exportedFile = null },
            icon = { Icon(Icons.Default.Check, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary) },
            title = { Text("Audio Trimmed Successfully") },
            text = {
                Column {
                    Text("File: ${file.name}")
                    Text("Size: ${(file.length() / 1024)} KB")
                    Text("Saved to workspace. 100% processed locally on device.")
                }
            },
            confirmButton = {
                Button(onClick = { onOpenFile(file) }) {
                    Text("Play / Open")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { onShareFile(file) }) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Share")
                }
            }
        )
    }
}
