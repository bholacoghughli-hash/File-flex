package com.example.ui.screens

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.localization.AppLanguage
import com.example.ui.screens.editor.AudioEditorView
import com.example.ui.screens.editor.DocumentEditorView
import com.example.ui.screens.editor.ImageEditorView
import com.example.ui.screens.editor.PdfEditorView
import com.example.ui.screens.editor.VideoEditorView
import com.example.ui.screens.editor.ZipToolsView
import com.example.viewmodel.EditorType
import com.example.viewmodel.MainViewModel
import java.io.File

@Composable
fun EditorScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val language by viewModel.appLanguage.collectAsState()
    val activeEditorType by viewModel.activeEditorType.collectAsState()
    val activeUri by viewModel.activeEditorUri.collectAsState()
    val activeFileName by viewModel.activeEditorFileName.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Mode Switcher Banner
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 1.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                FilterChip(
                    selected = activeEditorType == EditorType.PDF,
                    onClick = { viewModel.setEditorType(EditorType.PDF) },
                    leadingIcon = { Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    label = { Text("PDF") }
                )
                FilterChip(
                    selected = activeEditorType == EditorType.IMAGE,
                    onClick = { viewModel.setEditorType(EditorType.IMAGE) },
                    leadingIcon = { Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    label = { Text("Image") }
                )
                FilterChip(
                    selected = activeEditorType == EditorType.DOCUMENT,
                    onClick = { viewModel.setEditorType(EditorType.DOCUMENT) },
                    leadingIcon = { Icon(Icons.Default.Description, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    label = { Text("Document") }
                )
                FilterChip(
                    selected = activeEditorType == EditorType.AUDIO,
                    onClick = { viewModel.setEditorType(EditorType.AUDIO) },
                    leadingIcon = { Icon(Icons.Default.Audiotrack, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    label = { Text("Audio") }
                )
                FilterChip(
                    selected = activeEditorType == EditorType.VIDEO,
                    onClick = { viewModel.setEditorType(EditorType.VIDEO) },
                    leadingIcon = { Icon(Icons.Default.Videocam, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    label = { Text("Video") }
                )
                FilterChip(
                    selected = activeEditorType == EditorType.ZIP,
                    onClick = { viewModel.setEditorType(EditorType.ZIP) },
                    leadingIcon = { Icon(Icons.Default.FolderZip, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    label = { Text("ZIP") }
                )
            }
        }

        // Active Sub-Editor
        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            when (activeEditorType) {
                EditorType.PDF -> {
                    PdfEditorView(
                        initialUri = activeUri,
                        initialFileName = activeFileName,
                        language = language,
                        onSaveToWorkspace = { file, cat -> viewModel.addToWorkspace(file, tag = "EDITED", category = cat) },
                        onOpenFile = { file -> viewModel.openFile(context, file) },
                        onShareFile = { file -> viewModel.shareFile(context, file) }
                    )
                }
                EditorType.IMAGE -> {
                    ImageEditorView(
                        initialUri = activeUri,
                        initialFileName = activeFileName,
                        language = language,
                        onSaveToWorkspace = { file, cat -> viewModel.addToWorkspace(file, tag = "EDITED", category = cat) },
                        onOpenFile = { file -> viewModel.openFile(context, file) },
                        onShareFile = { file -> viewModel.shareFile(context, file) }
                    )
                }
                EditorType.DOCUMENT -> {
                    DocumentEditorView(
                        initialUri = activeUri,
                        initialFileName = activeFileName,
                        language = language,
                        onSaveToWorkspace = { file, cat -> viewModel.addToWorkspace(file, tag = "EDITED", category = cat) },
                        onOpenFile = { file -> viewModel.openFile(context, file) },
                        onShareFile = { file -> viewModel.shareFile(context, file) }
                    )
                }
                EditorType.AUDIO -> {
                    AudioEditorView(
                        initialUri = activeUri,
                        initialFileName = activeFileName,
                        language = language,
                        onSaveToWorkspace = { file, cat -> viewModel.addToWorkspace(file, tag = "EDITED", category = cat) },
                        onOpenFile = { file -> viewModel.openFile(context, file) },
                        onShareFile = { file -> viewModel.shareFile(context, file) }
                    )
                }
                EditorType.VIDEO -> {
                    VideoEditorView(
                        initialUri = activeUri,
                        initialFileName = activeFileName,
                        language = language,
                        onSaveToWorkspace = { file, cat -> viewModel.addToWorkspace(file, tag = "EDITED", category = cat) },
                        onOpenFile = { file -> viewModel.openFile(context, file) },
                        onShareFile = { file -> viewModel.shareFile(context, file) }
                    )
                }
                EditorType.ZIP -> {
                    ZipToolsView(
                        initialUri = activeUri,
                        initialFileName = activeFileName,
                        language = language,
                        onSaveToWorkspace = { file, cat -> viewModel.addToWorkspace(file, tag = "EDITED", category = cat) },
                        onOpenFile = { file -> viewModel.openFile(context, file) },
                        onShareFile = { file -> viewModel.shareFile(context, file) }
                    )
                }
            }
        }
    }
}
