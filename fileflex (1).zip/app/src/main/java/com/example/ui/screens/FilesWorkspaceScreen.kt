package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.WorkspaceEntity
import com.example.viewmodel.EditorType
import com.example.viewmodel.MainViewModel
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun FilesWorkspaceScreen(
    viewModel: MainViewModel,
    onNavigateToEditor: (EditorType) -> Unit,
    onNavigateToConvert: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val files by viewModel.filteredWorkspaceFiles.collectAsState()
    val searchQuery by viewModel.workspaceSearchQuery.collectAsState()
    val categoryFilter by viewModel.workspaceCategoryFilter.collectAsState()
    val tagFilter by viewModel.workspaceTagFilter.collectAsState()
    val sortOrder by viewModel.workspaceSortOrder.collectAsState()

    var fileToRename by remember { mutableStateOf<WorkspaceEntity?>(null) }
    var renameInput by remember { mutableStateOf("") }
    var fileToDelete by remember { mutableStateOf<WorkspaceEntity?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Privacy & Developer Banner
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
            tonalElevation = 1.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Your files are processed locally whenever supported • App developed by Bhaskar Gautam",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium),
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }

        // Search Bar
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 2.dp
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp)) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.setWorkspaceSearchQuery(it) },
                    placeholder = { Text("Search workspace files...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Tag Filter Row (All, Recent, Edited, Converted, Favorites)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FilterChip(
                        selected = tagFilter == "ALL",
                        onClick = { viewModel.setWorkspaceTagFilter("ALL") },
                        label = { Text("All") }
                    )
                    FilterChip(
                        selected = tagFilter == "RECENT",
                        onClick = { viewModel.setWorkspaceTagFilter("RECENT") },
                        label = { Text("Recent") }
                    )
                    FilterChip(
                        selected = tagFilter == "EDITED",
                        onClick = { viewModel.setWorkspaceTagFilter("EDITED") },
                        label = { Text("Edited") }
                    )
                    FilterChip(
                        selected = tagFilter == "CONVERTED",
                        onClick = { viewModel.setWorkspaceTagFilter("CONVERTED") },
                        label = { Text("Converted") }
                    )
                    FilterChip(
                        selected = tagFilter == "FAVORITES",
                        onClick = { viewModel.setWorkspaceTagFilter("FAVORITES") },
                        leadingIcon = { Icon(Icons.Default.Favorite, contentDescription = null, modifier = Modifier.size(14.dp)) },
                        label = { Text("Favorites") }
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Category Filter Row (All, PDF, Image, Doc, Audio, Video, Archive)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    listOf("ALL", "PDF", "IMAGE", "DOCUMENT", "AUDIO", "VIDEO", "ARCHIVE").forEach { cat ->
                        FilterChip(
                            selected = categoryFilter == cat,
                            onClick = { viewModel.setWorkspaceCategoryFilter(cat) },
                            label = { Text(cat.lowercase().replaceFirstChar { it.uppercase() }) }
                        )
                    }

                    // Sort order chip
                    var sortMenuOpen by remember { mutableStateOf(false) }
                    Box {
                        FilterChip(
                            selected = true,
                            onClick = { sortMenuOpen = true },
                            leadingIcon = { Icon(Icons.Default.Sort, contentDescription = null, modifier = Modifier.size(14.dp)) },
                            label = {
                                Text(
                                    when (sortOrder) {
                                        "NAME_ASC" -> "Sort: Name"
                                        "SIZE_DESC" -> "Sort: Size"
                                        else -> "Sort: Date"
                                    }
                                )
                            }
                        )
                        DropdownMenu(
                            expanded = sortMenuOpen,
                            onDismissRequest = { sortMenuOpen = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Date (Newest First)") },
                                onClick = {
                                    viewModel.setWorkspaceSortOrder("DATE_DESC")
                                    sortMenuOpen = false
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("File Name (A-Z)") },
                                onClick = {
                                    viewModel.setWorkspaceSortOrder("NAME_ASC")
                                    sortMenuOpen = false
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("File Size (Largest First)") },
                                onClick = {
                                    viewModel.setWorkspaceSortOrder("SIZE_DESC")
                                    sortMenuOpen = false
                                }
                            )
                        }
                    }
                }
            }
        }

        // File List or Empty State
        if (files.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                ElevatedCard(
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.FolderOpen,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Workspace is Empty",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Files you convert or edit will automatically appear here for instant management, editing, sharing, and organizing.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = onNavigateToConvert,
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("Convert a File")
                            }
                            OutlinedButton(
                                onClick = { onNavigateToEditor(EditorType.PDF) },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("Open Editor")
                            }
                        }
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(files, key = { it.id }) { item ->
                    val file = File(item.filePath)
                    val exists = file.exists()

                    ElevatedCard(
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.fillMaxWidth().padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Category Icon
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(getCategoryColor(item.category).copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = getCategoryIcon(item.category),
                                        contentDescription = null,
                                        tint = getCategoryColor(item.category),
                                        modifier = Modifier.size(24.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = item.fileName,
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                        maxLines = 1
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = item.formattedSize,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Text(" • ", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(
                                            text = SimpleDateFormat("MMM dd, HH:mm", Locale.getDefault()).format(Date(item.lastModified)),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Text(" • ", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(
                                            text = item.tag,
                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }

                                // Favorite Star
                                IconButton(
                                    onClick = { viewModel.toggleWorkspaceFavorite(item.id, item.isFavorite) }
                                ) {
                                    Icon(
                                        imageVector = if (item.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                        contentDescription = "Favorite",
                                        tint = if (item.isFavorite) Color(0xFFEF4444) else MaterialTheme.colorScheme.outline
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Action Buttons Row: Edit | Open | Share | Rename | Delete
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Edit button
                                Button(
                                    onClick = {
                                        if (exists) {
                                            val editorType = when (item.category.uppercase()) {
                                                "PDF" -> EditorType.PDF
                                                "IMAGE" -> EditorType.IMAGE
                                                "AUDIO" -> EditorType.AUDIO
                                                "VIDEO" -> EditorType.VIDEO
                                                "ARCHIVE" -> EditorType.ZIP
                                                else -> EditorType.DOCUMENT
                                            }
                                            viewModel.openInEditor(file, editorType)
                                            onNavigateToEditor(editorType)
                                        }
                                    },
                                    enabled = exists,
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Edit", fontSize = 11.sp)
                                }

                                // Open button
                                OutlinedButton(
                                    onClick = { if (exists) viewModel.openFile(context, file) },
                                    enabled = exists,
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.OpenInNew, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Open", fontSize = 11.sp)
                                }

                                // Share button
                                OutlinedButton(
                                    onClick = { if (exists) viewModel.shareFile(context, file) },
                                    enabled = exists,
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Share", fontSize = 11.sp)
                                }

                                // More menu (Rename, Delete)
                                var itemMenuOpen by remember { mutableStateOf(false) }
                                Box {
                                    IconButton(
                                        onClick = { itemMenuOpen = true },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(Icons.Default.MoreVert, contentDescription = "More")
                                    }
                                    DropdownMenu(
                                        expanded = itemMenuOpen,
                                        onDismissRequest = { itemMenuOpen = false }
                                    ) {
                                        DropdownMenuItem(
                                            text = { Text("Rename") },
                                            onClick = {
                                                itemMenuOpen = false
                                                fileToRename = item
                                                renameInput = item.fileName
                                            }
                                        )
                                        DropdownMenuItem(
                                            text = { Text("Convert this file") },
                                            onClick = {
                                                itemMenuOpen = false
                                                if (exists) {
                                                    viewModel.onFileSelected(context, android.net.Uri.fromFile(file))
                                                    onNavigateToConvert()
                                                }
                                            }
                                        )
                                        DropdownMenuItem(
                                            text = { Text("Delete from workspace", color = MaterialTheme.colorScheme.error) },
                                            onClick = {
                                                itemMenuOpen = false
                                                fileToDelete = item
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Rename Dialog
    if (fileToRename != null) {
        val target = fileToRename!!
        AlertDialog(
            onDismissRequest = { fileToRename = null },
            title = { Text("Rename File") },
            text = {
                OutlinedTextField(
                    value = renameInput,
                    onValueChange = { renameInput = it },
                    label = { Text("New file name") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (renameInput.isNotBlank()) {
                            viewModel.renameWorkspaceFile(target.id, renameInput)
                            fileToRename = null
                        }
                    }
                ) {
                    Text("Rename")
                }
            },
            dismissButton = {
                TextButton(onClick = { fileToRename = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Delete Confirmation Dialog
    if (fileToDelete != null) {
        val target = fileToDelete!!
        AlertDialog(
            onDismissRequest = { fileToDelete = null },
            title = { Text("Remove from Workspace") },
            text = {
                Text("Are you sure you want to remove '${target.fileName}' from your workspace? Original source files remain intact.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteWorkspaceFile(target, deletePhysical = false)
                        fileToDelete = null
                    },
                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Remove")
                }
            },
            dismissButton = {
                TextButton(onClick = { fileToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

private fun getCategoryColor(category: String): Color {
    return when (category.uppercase()) {
        "IMAGE" -> Color(0xFF10B981)
        "DOCUMENT", "PDF" -> Color(0xFF2563EB)
        "AUDIO" -> Color(0xFF8B5CF6)
        "VIDEO" -> Color(0xFFEF4444)
        "ARCHIVE" -> Color(0xFFF59E0B)
        else -> Color(0xFF6B7280)
    }
}

private fun getCategoryIcon(category: String): ImageVector {
    return when (category.uppercase()) {
        "IMAGE" -> Icons.Default.Image
        "PDF" -> Icons.Default.PictureAsPdf
        "DOCUMENT" -> Icons.Default.Description
        "AUDIO" -> Icons.Default.Audiotrack
        "VIDEO" -> Icons.Default.Videocam
        "ARCHIVE" -> Icons.Default.FolderZip
        else -> Icons.Default.Description
    }
}
