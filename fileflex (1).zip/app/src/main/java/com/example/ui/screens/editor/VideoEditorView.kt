package com.example.ui.screens.editor

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.VideoEditEngine
import com.example.localization.AppLanguage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun VideoEditorView(
    initialUri: Uri?,
    initialFileName: String,
    language: AppLanguage,
    onSaveToWorkspace: (File, String) -> Unit,
    onOpenFile: (File) -> Unit,
    onShareFile: (File) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var activeVideoUri by remember { mutableStateOf<Uri?>(initialUri) }
    var fileName by remember { mutableStateOf(initialFileName.ifBlank { "video_clip.mp4" }) }
    var totalDurationMs by remember { mutableLongStateOf(0L) }
    var videoWidth by remember { mutableStateOf("1920") }
    var videoHeight by remember { mutableStateOf("1080") }
    var previewThumbnail by remember { mutableStateOf<Bitmap?>(null) }

    var trimStartSec by remember { mutableFloatStateOf(0f) }
    var trimEndSec by remember { mutableFloatStateOf(0f) }

    var isLoading by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf("") }
    var exportedFile by remember { mutableStateOf<File?>(null) }

    fun loadVideoInfo(uri: Uri) {
        scope.launch(Dispatchers.IO) {
            try {
                val retriever = MediaMetadataRetriever()
                retriever.setDataSource(context, uri)
                val durStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                val dur = durStr?.toLongOrNull() ?: 0L
                val w = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH) ?: "1920"
                val h = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT) ?: "1080"
                val thumb = retriever.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                retriever.release()

                withContext(Dispatchers.Main) {
                    totalDurationMs = dur
                    videoWidth = w
                    videoHeight = h
                    previewThumbnail = thumb
                    trimStartSec = 0f
                    trimEndSec = (dur / 1000f).coerceAtLeast(0f)
                }
            } catch (_: Exception) {}
        }
    }

    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            activeVideoUri = it
            fileName = "video_${System.currentTimeMillis()}.mp4"
            loadVideoInfo(it)
        }
    }

    LaunchedEffect(initialUri) {
        if (initialUri != null) {
            loadVideoInfo(initialUri)
        }
    }

    fun executeTrim() {
        val uri = activeVideoUri ?: return
        scope.launch {
            isLoading = true
            statusMessage = "Trimming video stream..."
            try {
                val outFile = File(context.cacheDir, "trimmed_${System.currentTimeMillis()}.mp4")
                val result = VideoEditEngine.trimVideo(
                    context = context,
                    inputUri = uri,
                    startMs = (trimStartSec * 1000L).toLong(),
                    endMs = (trimEndSec * 1000L).toLong(),
                    outputFile = outFile,
                    onProgress = { p -> statusMessage = "Trimming Video (${(p * 100).toInt()}%)" }
                )
                exportedFile = result
                onSaveToWorkspace(result, "VIDEO")
                statusMessage = "Video trimmed successfully!"
            } catch (e: Exception) {
                statusMessage = "Trimming failed: ${e.message}"
            } finally {
                isLoading = false
            }
        }
    }

    fun extractAudio() {
        val uri = activeVideoUri ?: return
        scope.launch {
            isLoading = true
            statusMessage = "Extracting audio track..."
            try {
                val outFile = File(context.cacheDir, "extracted_audio_${System.currentTimeMillis()}.m4a")
                val result = VideoEditEngine.extractAudioStreamToM4a(
                    context = context,
                    inputUri = uri,
                    outputFile = outFile,
                    onProgress = { p -> statusMessage = "Extracting Audio (${(p * 100).toInt()}%)" }
                )
                exportedFile = result
                onSaveToWorkspace(result, "AUDIO")
                statusMessage = "Audio track extracted successfully!"
            } catch (e: Exception) {
                statusMessage = "Extraction failed: ${e.message}"
            } finally {
                isLoading = false
            }
        }
    }

    fun captureFrame() {
        val uri = activeVideoUri ?: return
        scope.launch {
            isLoading = true
            statusMessage = "Capturing video frame..."
            try {
                val outFile = File(context.cacheDir, "frame_${System.currentTimeMillis()}.jpg")
                val result = withContext(Dispatchers.IO) {
                    VideoEditEngine.extractFrameAtTime(
                        context = context,
                        inputUri = uri,
                        timeSeconds = trimStartSec,
                        targetFormat = "jpg",
                        outputFile = outFile
                    )
                }
                exportedFile = result
                onSaveToWorkspace(result, "IMAGE")
                statusMessage = "Frame captured successfully!"
            } catch (e: Exception) {
                statusMessage = "Capture failed: ${e.message}"
            } finally {
                isLoading = false
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Top Toolbar
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 2.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Videocam,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = fileName,
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            maxLines = 1
                        )
                        Text(
                            text = String.format("%.1fs • %s × %s px", totalDurationMs / 1000f, videoWidth, videoHeight),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Button(
                        onClick = { videoPickerLauncher.launch("video/*") },
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text("Open Video", fontSize = 12.sp)
                    }
                    if (activeVideoUri != null) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Button(
                            onClick = { executeTrim() },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.ContentCut, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Trim & Save", fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        if (activeVideoUri == null) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                ElevatedCard(
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.errorContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Videocam,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Video Trimmer & Extractor",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Losslessly trim video clips, extract audio soundtrack (M4A), capture high-resolution video frames as JPG, and export 100% locally on device.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        Button(
                            onClick = { videoPickerLauncher.launch("video/*") },
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Select Video to Edit")
                        }
                    }
                }
            }
        } else {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
            ) {
                // Video Preview Poster
                ElevatedCard(
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp)
                            .background(Color.Black),
                        contentAlignment = Alignment.Center
                    ) {
                        if (previewThumbnail != null) {
                            Image(
                                bitmap = previewThumbnail!!.asImageBitmap(),
                                contentDescription = "Video preview",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Fit
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = Color.White.copy(alpha = 0.7f),
                                modifier = Modifier.size(48.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Trimming Sliders Card
                ElevatedCard(
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp)
                    ) {
                        Text(
                            text = "Trim Range",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        val maxSec = (totalDurationMs / 1000f).coerceAtLeast(1f)

                        Text(
                            text = String.format("Start Time: %.1fs", trimStartSec),
                            style = MaterialTheme.typography.labelSmall
                        )
                        Slider(
                            value = trimStartSec,
                            onValueChange = { trimStartSec = it.coerceAtMost(trimEndSec - 0.5f) },
                            valueRange = 0f..maxSec
                        )

                        Text(
                            text = String.format("End Time: %.1fs (Selected Length: %.1fs)", trimEndSec, (trimEndSec - trimStartSec).coerceAtLeast(0f)),
                            style = MaterialTheme.typography.labelSmall
                        )
                        Slider(
                            value = trimEndSec,
                            onValueChange = { trimEndSec = it.coerceAtLeast(trimStartSec + 0.5f) },
                            valueRange = 0f..maxSec
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Quick Tools
                ElevatedCard(
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp)
                    ) {
                        Text(
                            text = "Quick Video Tools",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        FlowRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedButton(
                                onClick = { extractAudio() },
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.Audiotrack, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Extract Audio Track (M4A)")
                            }

                            OutlinedButton(
                                onClick = { captureFrame() },
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Capture Frame at Start (JPG)")
                            }
                        }
                    }
                }

                if (isLoading) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(statusMessage, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }

    // Success Dialog
    if (exportedFile != null) {
        val file = exportedFile!!
        AlertDialog(
            onDismissRequest = { exportedFile = null },
            icon = { Icon(Icons.Default.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
            title = { Text("Video Processed Successfully") },
            text = {
                Column {
                    Text("File: ${file.name}")
                    Text("Size: ${(file.length() / (1024 * 1024.0)).let { String.format("%.2f MB", it) }}")
                    Text("Saved to workspace. 100% processed locally on device.")
                }
            },
            confirmButton = {
                Button(onClick = { onOpenFile(file) }) {
                    Text("Open / Play")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { onShareFile(file) }) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Share")
                }
            }
        )
    }
}
