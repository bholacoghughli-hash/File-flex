package com.example.ui.screens.editor

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.FindReplace
import androidx.compose.material.icons.filled.FormatBold
import androidx.compose.material.icons.filled.FormatItalic
import androidx.compose.material.icons.filled.FormatListBulleted
import androidx.compose.material.icons.filled.FormatQuote
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.DocumentEditEngine
import com.example.localization.AppLanguage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DocumentEditorView(
    initialUri: Uri?,
    initialFileName: String,
    language: AppLanguage,
    onSaveToWorkspace: (File, String) -> Unit,
    onOpenFile: (File) -> Unit,
    onShareFile: (File) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var documentText by remember { mutableStateOf("") }
    var fileName by remember { mutableStateOf(initialFileName.ifBlank { "document.txt" }) }
    var isLoading by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf("") }

    var isPreviewMode by remember { mutableStateOf(false) }
    var showSearchReplace by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var replaceQuery by remember { mutableStateOf("") }
    var occurrencesCount by remember { mutableStateOf(0) }

    var exportedFile by remember { mutableStateOf<File?>(null) }
    var showExportDialog by remember { mutableStateOf(false) }
    var targetFormat by remember { mutableStateOf("txt") }

    // Stats
    val wordCount = remember(documentText) {
        if (documentText.isBlank()) 0 else documentText.trim().split("\\s+".toRegex()).size
    }
    val charCount = remember(documentText) { documentText.length }
    val lineCount = remember(documentText) {
        if (documentText.isEmpty()) 1 else documentText.count { it == '\n' } + 1
    }

    // Document Picker
    val docPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            scope.launch {
                isLoading = true
                statusMessage = "Loading document..."
                try {
                    val text = DocumentEditEngine.readTextFromUri(context, it)
                    documentText = text
                    fileName = "edited_${System.currentTimeMillis()}.txt"
                } catch (e: Exception) {
                    statusMessage = "Could not open document: ${e.message}"
                } finally {
                    isLoading = false
                }
            }
        }
    }

    // Load initial file if provided
    LaunchedEffect(initialUri) {
        if (initialUri != null && documentText.isEmpty()) {
            isLoading = true
            statusMessage = "Loading document..."
            try {
                val text = DocumentEditEngine.readTextFromUri(context, initialUri)
                documentText = text
            } catch (_: Exception) {
                statusMessage = "Failed to load document"
            } finally {
                isLoading = false
            }
        }
    }

    fun executeReplaceAll() {
        if (searchQuery.isNotEmpty()) {
            documentText = documentText.replace(searchQuery, replaceQuery)
            searchQuery = ""
            occurrencesCount = 0
        }
    }

    fun saveDocument(format: String) {
        scope.launch {
            isLoading = true
            statusMessage = "Exporting document..."
            try {
                val ext = format.lowercase().trimStart('.')
                val outFile = File(context.cacheDir, "document_${System.currentTimeMillis()}.$ext")

                val result = if (ext == "pdf") {
                    DocumentEditEngine.exportTextToPdf(
                        text = documentText,
                        title = fileName.substringBeforeLast('.'),
                        outputFile = outFile,
                        onProgress = { p -> statusMessage = "Rendering PDF (${(p * 100).toInt()}%)" }
                    )
                } else {
                    DocumentEditEngine.saveTextToFile(documentText, outFile)
                }

                exportedFile = result
                onSaveToWorkspace(result, if (ext == "pdf") "PDF" else "DOCUMENT")
                statusMessage = "Saved successfully!"
            } catch (e: Exception) {
                statusMessage = "Export failed: ${e.message}"
            } finally {
                isLoading = false
                showExportDialog = false
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Top Toolbar
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 2.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Description,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = fileName,
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            maxLines = 1
                        )
                        Text(
                            text = "$wordCount words • $charCount chars • $lineCount lines",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Button(
                        onClick = { docPickerLauncher.launch(arrayOf("text/*", "application/json", "application/xml", "application/pdf")) },
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Open", fontSize = 12.sp)
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Button(
                        onClick = { showExportDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Export", fontSize = 12.sp)
                    }
                }
            }
        }

        // Action Ribbon: Search & Replace, Format Helpers, View Toggle
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 10.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                FilterChip(
                    selected = isPreviewMode,
                    onClick = { isPreviewMode = !isPreviewMode },
                    leadingIcon = { Icon(Icons.Default.Visibility, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    label = { Text(if (isPreviewMode) "Edit Mode" else "Preview") }
                )

                FilterChip(
                    selected = showSearchReplace,
                    onClick = { showSearchReplace = !showSearchReplace },
                    leadingIcon = { Icon(Icons.Default.FindReplace, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    label = { Text("Find / Replace") }
                )

                IconButton(onClick = { documentText += "**bold text**" }) {
                    Icon(Icons.Default.FormatBold, contentDescription = "Bold", modifier = Modifier.size(18.dp))
                }
                IconButton(onClick = { documentText += "*italic text*" }) {
                    Icon(Icons.Default.FormatItalic, contentDescription = "Italic", modifier = Modifier.size(18.dp))
                }
                IconButton(onClick = { documentText += "\n# Header 1\n" }) {
                    Text("H1", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
                IconButton(onClick = { documentText += "\n- Bullet item\n" }) {
                    Icon(Icons.Default.FormatListBulleted, contentDescription = "List", modifier = Modifier.size(18.dp))
                }
                IconButton(onClick = { documentText += "\n> Quote\n" }) {
                    Icon(Icons.Default.FormatQuote, contentDescription = "Quote", modifier = Modifier.size(18.dp))
                }
                IconButton(onClick = { documentText += "\n```\ncode block\n```\n" }) {
                    Text("</>", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }

        // Search & Replace Sub-Bar
        if (showSearchReplace) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 1.dp
            ) {
                Column(modifier = Modifier.fillMaxWidth().padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = {
                                searchQuery = it
                                occurrencesCount = if (it.isEmpty()) 0 else documentText.split(it).size - 1
                            },
                            label = { Text("Find text") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = replaceQuery,
                            onValueChange = { replaceQuery = it },
                            label = { Text("Replace with") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        Button(
                            onClick = { executeReplaceAll() },
                            enabled = searchQuery.isNotEmpty()
                        ) {
                            Text("Replace All")
                        }
                    }
                    if (searchQuery.isNotEmpty()) {
                        Text(
                            text = "Found $occurrencesCount occurrences in document",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }
        }

        // Live Editor Workspace
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(if (isPreviewMode) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f))
                .padding(12.dp)
        ) {
            if (isLoading) {
                Column(
                    modifier = Modifier.align(Alignment.Center),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    CircularProgressIndicator(modifier = Modifier.size(36.dp))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(statusMessage, style = MaterialTheme.typography.bodySmall)
                }
            } else if (isPreviewMode) {
                // Rendered Reading View
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(8.dp)
                ) {
                    Text(
                        text = documentText.ifBlank { "Nothing to preview. Enter some text in Edit Mode." },
                        style = MaterialTheme.typography.bodyLarge.copy(
                            lineHeight = 26.sp,
                            fontFamily = FontFamily.Default
                        ),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            } else {
                // Code & Text Editor View with Line Numbers
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                ) {
                    // Line numbers column
                    val lines = documentText.split("\n")
                    Column(
                        modifier = Modifier
                            .width(36.dp)
                            .padding(end = 8.dp),
                        horizontalAlignment = Alignment.End
                    ) {
                        for (i in 1..lines.size.coerceAtLeast(1)) {
                            Text(
                                text = "$i",
                                style = TextStyle(
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.outline.copy(alpha = 0.6f),
                                    lineHeight = 22.sp
                                )
                            )
                        }
                    }

                    // Raw Text Field
                    BasicTextField(
                        value = documentText,
                        onValueChange = { documentText = it },
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxSize(),
                        textStyle = TextStyle(
                            fontFamily = FontFamily.Monospace,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface,
                            lineHeight = 22.sp
                        ),
                        cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                        decorationBox = { innerTextField ->
                            if (documentText.isEmpty()) {
                                Text(
                                    text = "Start typing document content here, or tap 'Open' to load a file...",
                                    style = TextStyle(
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.outline
                                    )
                                )
                            }
                            innerTextField()
                        }
                    )
                }
            }
        }
    }

    // Export Dialog
    if (showExportDialog) {
        AlertDialog(
            onDismissRequest = { showExportDialog = false },
            title = { Text("Export Document") },
            text = {
                Column {
                    Text("Select output format to save:", style = MaterialTheme.typography.bodySmall)
                    Spacer(modifier = Modifier.height(10.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("txt", "md", "html", "csv", "json", "pdf").forEach { fmt ->
                            FilterChip(
                                selected = targetFormat == fmt,
                                onClick = { targetFormat = fmt },
                                label = { Text(fmt.uppercase()) }
                            )
                        }
                    }
                    if (targetFormat == "pdf") {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Will be rendered into an elegant multi-page A4 PDF document with page numbering.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            },
            confirmButton = {
                Button(onClick = { saveDocument(targetFormat) }) {
                    Text("Save / Export")
                }
            },
            dismissButton = {
                TextButton(onClick = { showExportDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Exported Dialog
    if (exportedFile != null) {
        val file = exportedFile!!
        AlertDialog(
            onDismissRequest = { exportedFile = null },
            icon = { Icon(Icons.Default.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
            title = { Text("Document Saved Successfully") },
            text = {
                Column {
                    Text("File: ${file.name}")
                    Text("Size: ${(file.length() / 1024)} KB")
                    Text("Saved to workspace. 100% processed locally on device.")
                }
            },
            confirmButton = {
                Button(onClick = { onOpenFile(file) }) {
                    Text("Open")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { onShareFile(file) }) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Share")
                }
            }
        )
    }
}
