package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.ConversionHistoryEntity
import com.example.data.HistoryRepository
import com.example.data.WorkspaceEntity
import com.example.data.WorkspaceRepository
import com.example.engine.ArchiveEngine
import com.example.engine.ConversionManager
import com.example.engine.FileTypeDetector
import com.example.localization.AppLanguage
import com.example.localization.StringsProvider
import com.example.model.ConversionJob
import com.example.model.ConversionOptions
import com.example.model.FileCategory
import com.example.model.FileFormat
import com.example.model.FileInfo
import com.example.model.JobStatus
import com.example.model.SupportedFormats
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

enum class EditorType {
    PDF,
    IMAGE,
    DOCUMENT,
    AUDIO,
    VIDEO,
    ZIP
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val repository = HistoryRepository(db.historyDao())
    private val workspaceRepository = WorkspaceRepository(db.workspaceDao())
    private val conversionManager = ConversionManager(application, repository)

    // Current app preferences
    private val _appLanguage = MutableStateFlow(AppLanguage.ENGLISH)
    val appLanguage: StateFlow<AppLanguage> = _appLanguage.asStateFlow()

    private val _themeMode = MutableStateFlow("SYSTEM") // SYSTEM, LIGHT, DARK
    val themeMode: StateFlow<String> = _themeMode.asStateFlow()

    // Single File Conversion States
    private val _selectedFileInfo = MutableStateFlow<FileInfo?>(null)
    val selectedFileInfo: StateFlow<FileInfo?> = _selectedFileInfo.asStateFlow()

    private val _availableOutputFormats = MutableStateFlow<List<FileFormat>>(emptyList())
    val availableOutputFormats: StateFlow<List<FileFormat>> = _availableOutputFormats.asStateFlow()

    private val _selectedTargetFormat = MutableStateFlow<FileFormat?>(null)
    val selectedTargetFormat: StateFlow<FileFormat?> = _selectedTargetFormat.asStateFlow()

    private val _conversionOptions = MutableStateFlow(ConversionOptions())
    val conversionOptions: StateFlow<ConversionOptions> = _conversionOptions.asStateFlow()

    private val _currentJob = MutableStateFlow<ConversionJob?>(null)
    val currentJob: StateFlow<ConversionJob?> = _currentJob.asStateFlow()

    private var activeJobExecution: Job? = null

    // Batch Queue States
    private val _batchQueue = MutableStateFlow<List<ConversionJob>>(emptyList())
    val batchQueue: StateFlow<List<ConversionJob>> = _batchQueue.asStateFlow()

    private val _isBatchProcessing = MutableStateFlow(false)
    val isBatchProcessing: StateFlow<Boolean> = _isBatchProcessing.asStateFlow()

    // History Search & Filtering
    private val _historySearchQuery = MutableStateFlow("")
    val historySearchQuery: StateFlow<String> = _historySearchQuery.asStateFlow()

    private val _historyCategoryFilter = MutableStateFlow("ALL")
    val historyCategoryFilter: StateFlow<String> = _historyCategoryFilter.asStateFlow()

    val filteredHistory: StateFlow<List<ConversionHistoryEntity>> = combine(
        repository.allHistory,
        _historySearchQuery,
        _historyCategoryFilter
    ) { list, query, filter ->
        list.filter { item ->
            val matchesQuery = query.isBlank() ||
                    item.fileName.contains(query, ignoreCase = true) ||
                    item.outputFileName.contains(query, ignoreCase = true)
            val matchesCategory = filter == "ALL" || item.category.equals(filter, ignoreCase = true)
            matchesQuery && matchesCategory
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Workspace Management States
    private val _workspaceSearchQuery = MutableStateFlow("")
    val workspaceSearchQuery: StateFlow<String> = _workspaceSearchQuery.asStateFlow()

    private val _workspaceCategoryFilter = MutableStateFlow("ALL")
    val workspaceCategoryFilter: StateFlow<String> = _workspaceCategoryFilter.asStateFlow()

    private val _workspaceTagFilter = MutableStateFlow("ALL") // ALL, RECENT, EDITED, CONVERTED, FAVORITES
    val workspaceTagFilter: StateFlow<String> = _workspaceTagFilter.asStateFlow()

    private val _workspaceSortOrder = MutableStateFlow("DATE_DESC") // DATE_DESC, NAME_ASC, SIZE_DESC
    val workspaceSortOrder: StateFlow<String> = _workspaceSortOrder.asStateFlow()

    val filteredWorkspaceFiles: StateFlow<List<WorkspaceEntity>> = combine(
        workspaceRepository.allFiles,
        _workspaceSearchQuery,
        _workspaceCategoryFilter,
        _workspaceTagFilter,
        _workspaceSortOrder
    ) { list, query, category, tag, sort ->
        val filtered = list.filter { item ->
            val matchesQuery = query.isBlank() || item.fileName.contains(query, ignoreCase = true)
            val matchesCategory = category == "ALL" || item.category.equals(category, ignoreCase = true)
            val matchesTag = when (tag) {
                "FAVORITES" -> item.isFavorite
                "RECENT" -> true
                "EDITED" -> item.tag.equals("EDITED", ignoreCase = true)
                "CONVERTED" -> item.tag.equals("CONVERTED", ignoreCase = true)
                else -> true
            }
            matchesQuery && matchesCategory && matchesTag
        }
        when (sort) {
            "NAME_ASC" -> filtered.sortedBy { it.fileName.lowercase() }
            "SIZE_DESC" -> filtered.sortedByDescending { it.sizeBytes }
            else -> filtered.sortedByDescending { it.lastModified }
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Active Editor State
    private val _activeEditorType = MutableStateFlow(EditorType.PDF)
    val activeEditorType: StateFlow<EditorType> = _activeEditorType.asStateFlow()

    private val _activeEditorUri = MutableStateFlow<Uri?>(null)
    val activeEditorUri: StateFlow<Uri?> = _activeEditorUri.asStateFlow()

    private val _activeEditorFileName = MutableStateFlow("")
    val activeEditorFileName: StateFlow<String> = _activeEditorFileName.asStateFlow()

    fun setEditorType(type: EditorType) {
        _activeEditorType.value = type
    }

    fun openInEditor(file: File, type: EditorType? = null) {
        val detected = type ?: when (file.extension.lowercase()) {
            "pdf" -> EditorType.PDF
            in listOf("jpg", "jpeg", "png", "webp", "bmp", "gif", "ico") -> EditorType.IMAGE
            in listOf("mp3", "wav", "m4a", "aac", "ogg", "flac") -> EditorType.AUDIO
            in listOf("mp4", "mkv", "mov", "webm", "avi", "3gp") -> EditorType.VIDEO
            in listOf("zip", "rar", "7z", "tar", "gz") -> EditorType.ZIP
            else -> EditorType.DOCUMENT
        }
        _activeEditorType.value = detected
        _activeEditorUri.value = Uri.fromFile(file)
        _activeEditorFileName.value = file.name
    }

    fun openUriInEditor(context: Context, uri: Uri, fileName: String, type: EditorType? = null) {
        val ext = fileName.substringAfterLast('.', "").lowercase()
        val detected = type ?: when (ext) {
            "pdf" -> EditorType.PDF
            in listOf("jpg", "jpeg", "png", "webp", "bmp", "gif", "ico") -> EditorType.IMAGE
            in listOf("mp3", "wav", "m4a", "aac", "ogg", "flac") -> EditorType.AUDIO
            in listOf("mp4", "mkv", "mov", "webm", "avi", "3gp") -> EditorType.VIDEO
            in listOf("zip", "rar", "7z", "tar", "gz") -> EditorType.ZIP
            else -> EditorType.DOCUMENT
        }
        _activeEditorType.value = detected
        _activeEditorUri.value = uri
        _activeEditorFileName.value = fileName
    }

    fun addToWorkspace(file: File, tag: String = "EDITED", category: String = "DOCUMENT") {
        viewModelScope.launch(Dispatchers.IO) {
            workspaceRepository.addFile(file, tag = tag, category = category)
        }
    }

    fun toggleWorkspaceFavorite(id: Long, current: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            workspaceRepository.toggleFavorite(id, current)
        }
    }

    fun renameWorkspaceFile(id: Long, newName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            workspaceRepository.rename(id, newName)
        }
    }

    fun deleteWorkspaceFile(entity: WorkspaceEntity, deletePhysical: Boolean = false) {
        viewModelScope.launch(Dispatchers.IO) {
            workspaceRepository.remove(entity, deletePhysical)
        }
    }

    fun setWorkspaceSearchQuery(q: String) {
        _workspaceSearchQuery.value = q
    }

    fun setWorkspaceCategoryFilter(cat: String) {
        _workspaceCategoryFilter.value = cat
    }

    fun setWorkspaceTagFilter(tag: String) {
        _workspaceTagFilter.value = tag
    }

    fun setWorkspaceSortOrder(order: String) {
        _workspaceSortOrder.value = order
    }

    // Cache Stats & UI Notifications
    private val _cacheSizeBytes = MutableStateFlow(0L)
    val cacheSizeBytes: StateFlow<Long> = _cacheSizeBytes.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    init {
        refreshCacheSize()
    }

    fun setLanguage(lang: AppLanguage) {
        _appLanguage.value = lang
    }

    fun setThemeMode(mode: String) {
        _themeMode.value = mode
    }

    fun clearToast() {
        _toastMessage.value = null
    }

    fun showToast(msg: String) {
        _toastMessage.value = msg
    }

    fun refreshCacheSize() {
        viewModelScope.launch(Dispatchers.IO) {
            _cacheSizeBytes.value = conversionManager.getCacheSizeBytes()
        }
    }

    fun clearCache() {
        viewModelScope.launch(Dispatchers.IO) {
            val freed = conversionManager.clearTemporaryCache()
            _cacheSizeBytes.value = 0L
            _toastMessage.value = "Cleared ${(freed / 1024).coerceAtLeast(0)} KB of temporary files"
        }
    }

    // Single File Selection
    fun onFileSelected(context: Context, uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val info = FileTypeDetector.detectFileInfo(context, uri)
            _selectedFileInfo.value = info

            val outputs = SupportedFormats.getAvailableOutputs(info.category, info.extension)
            _availableOutputFormats.value = outputs
            _selectedTargetFormat.value = outputs.firstOrNull()
            _currentJob.value = null
        }
    }

    fun selectTargetFormat(format: FileFormat) {
        _selectedTargetFormat.value = format
    }

    fun updateConversionOptions(options: ConversionOptions) {
        _conversionOptions.value = options
    }

    fun startSingleConversion(context: Context) {
        val fileInfo = _selectedFileInfo.value ?: return
        val targetFormat = _selectedTargetFormat.value ?: return

        val initialJob = ConversionJob(
            fileInfo = fileInfo,
            targetFormat = targetFormat,
            options = _conversionOptions.value,
            status = JobStatus.CONVERTING,
            progress = 0.05f,
            statusMessage = "Starting conversion..."
        )
        _currentJob.value = initialJob

        activeJobExecution?.cancel()
        activeJobExecution = viewModelScope.launch {
            val resultJob = conversionManager.executeConversion(initialJob) { p, msg ->
                _currentJob.value = _currentJob.value?.copy(progress = p, statusMessage = msg)
            }
            _currentJob.value = resultJob
            resultJob.convertedFile?.let { converted ->
                addToWorkspace(converted, tag = "CONVERTED", category = initialJob.fileInfo.category.name)
            }
            refreshCacheSize()
        }
    }

    fun cancelSingleConversion() {
        activeJobExecution?.cancel()
        _currentJob.value = _currentJob.value?.copy(
            status = JobStatus.CANCELLED,
            statusMessage = "Cancelled by user"
        )
    }

    fun resetSingleConversion() {
        _currentJob.value = null
        _selectedFileInfo.value = null
        _selectedTargetFormat.value = null
    }

    // Batch Queue Operations
    fun onMultipleFilesSelected(context: Context, uris: List<Uri>) {
        viewModelScope.launch(Dispatchers.IO) {
            val newJobs = uris.mapNotNull { uri ->
                val info = FileTypeDetector.detectFileInfo(context, uri)
                val outputs = SupportedFormats.getAvailableOutputs(info.category, info.extension)
                val target = outputs.firstOrNull()
                if (target != null) {
                    ConversionJob(
                        fileInfo = info,
                        targetFormat = target,
                        options = _conversionOptions.value,
                        status = JobStatus.WAITING,
                        statusMessage = "Queued"
                    )
                } else null
            }
            _batchQueue.value = _batchQueue.value + newJobs
        }
    }

    fun updateBatchItemTarget(jobId: String, newTarget: FileFormat) {
        _batchQueue.value = _batchQueue.value.map { job ->
            if (job.id == jobId) job.copy(targetFormat = newTarget) else job
        }
    }

    fun removeBatchItem(jobId: String) {
        _batchQueue.value = _batchQueue.value.filter { it.id != jobId }
    }

    fun clearBatchQueue() {
        _batchQueue.value = emptyList()
    }

    fun startBatchConversion() {
        if (_isBatchProcessing.value) return
        _isBatchProcessing.value = true

        viewModelScope.launch {
            val jobs = _batchQueue.value.toMutableList()
            for (i in jobs.indices) {
                val job = jobs[i]
                if (job.status == JobStatus.WAITING || job.status == JobStatus.FAILED) {
                    jobs[i] = job.copy(status = JobStatus.CONVERTING, progress = 0.05f, statusMessage = "Processing...")
                    _batchQueue.value = jobs.toList()

                    val finished = conversionManager.executeConversion(job) { p, msg ->
                        jobs[i] = jobs[i].copy(progress = p, statusMessage = msg)
                        _batchQueue.value = jobs.toList()
                    }
                    jobs[i] = finished
                    _batchQueue.value = jobs.toList()
                    finished.convertedFile?.let { converted ->
                        addToWorkspace(converted, tag = "CONVERTED", category = job.fileInfo.category.name)
                    }
                }
            }
            _isBatchProcessing.value = false
            refreshCacheSize()
        }
    }

    fun retryFailedBatchItem(jobId: String) {
        viewModelScope.launch {
            val list = _batchQueue.value.toMutableList()
            val index = list.indexOfFirst { it.id == jobId }
            if (index != -1) {
                val job = list[index]
                list[index] = job.copy(status = JobStatus.CONVERTING, progress = 0.05f, statusMessage = "Retrying...")
                _batchQueue.value = list.toList()

                val result = conversionManager.executeConversion(job) { p, msg ->
                    list[index] = list[index].copy(progress = p, statusMessage = msg)
                    _batchQueue.value = list.toList()
                }
                list[index] = result
                _batchQueue.value = list.toList()
                refreshCacheSize()
            }
        }
    }

    fun exportBatchAsZip(context: Context, onComplete: (File?) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val completedFiles = _batchQueue.value
                .mapNotNull { it.convertedFile }
                .filter { it.exists() }

            if (completedFiles.isEmpty()) {
                withContext(Dispatchers.Main) { onComplete(null) }
                return@launch
            }

            val zipOut = File(context.cacheDir, "conversions/FileFlex_Batch_${System.currentTimeMillis()}.zip")
            ArchiveEngine.createZipFromFiles(completedFiles, zipOut) { }
            withContext(Dispatchers.Main) {
                onComplete(zipOut)
            }
        }
    }

    // History Operations
    fun setHistorySearchQuery(q: String) {
        _historySearchQuery.value = q
    }

    fun setHistoryCategoryFilter(cat: String) {
        _historyCategoryFilter.value = cat
    }

    fun deleteHistoryItem(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteById(id)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.clearAll()
        }
    }

    // Sharing / Opening Helper
    fun shareFile(context: Context, file: File) {
        try {
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "*/*"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Share converted file via"))
        } catch (e: Exception) {
            showToast("Failed to open share sheet: ${e.localizedMessage}")
        }
    }

    fun openFile(context: Context, file: File) {
        try {
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "*/*")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(intent, "Open file with"))
        } catch (e: Exception) {
            showToast("No compatible app found to open this file")
        }
    }
}
