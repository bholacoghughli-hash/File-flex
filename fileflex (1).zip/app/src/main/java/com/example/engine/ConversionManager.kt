package com.example.engine

import android.content.Context
import com.example.data.ConversionHistoryEntity
import com.example.data.HistoryRepository
import com.example.model.ConversionJob
import com.example.model.FileCategory
import com.example.model.JobStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class ConversionManager(
    private val context: Context,
    private val historyRepository: HistoryRepository
) {
    private val conversionDir: File by lazy {
        val dir = File(context.cacheDir, "conversions")
        if (!dir.exists()) dir.mkdirs()
        dir
    }

    suspend fun executeConversion(
        job: ConversionJob,
        onProgressUpdate: (Float, String) -> Unit
    ): ConversionJob = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        val originalInfo = job.fileInfo
        val targetExt = job.targetFormat.extension

        val outputName = SafeFileNameGenerator.generateOutputFileName(
            originalName = originalInfo.name,
            targetExtension = targetExt,
            destinationDir = conversionDir
        )
        val outputFile = File(conversionDir, outputName)

        try {
            onProgressUpdate(0.05f, "Preparing file...")

            when (originalInfo.category) {
                FileCategory.IMAGE -> {
                    if (targetExt == "pdf") {
                        DocumentConversionEngine.convertImagesToPdf(
                            context = context,
                            imageUris = listOf(originalInfo.uri),
                            options = job.options,
                            outputFile = outputFile,
                            onProgress = { p -> onProgressUpdate(p, "Generating PDF (${(p * 100).toInt()}%)") }
                        )
                    } else if (targetExt == "zip") {
                        ArchiveEngine.createZipFromUris(
                            context = context,
                            uris = listOf(Pair(originalInfo.uri, originalInfo.name)),
                            outputZipFile = outputFile,
                            onProgress = { p -> onProgressUpdate(p, "Compressing ZIP (${(p * 100).toInt()}%)") }
                        )
                    } else {
                        ImageConversionEngine.convertImage(
                            context = context,
                            inputUri = originalInfo.uri,
                            targetExtension = targetExt,
                            options = job.options,
                            outputFile = outputFile,
                            onProgress = { p -> onProgressUpdate(p, "Encoding $targetExt (${(p * 100).toInt()}%)") }
                        )
                    }
                }

                FileCategory.DOCUMENT -> {
                    val inputExt = originalInfo.extension.lowercase()
                    when {
                        targetExt == "pdf" && inputExt in listOf("txt", "md", "csv", "log") -> {
                            DocumentConversionEngine.convertTxtToPdf(
                                context = context,
                                inputUri = originalInfo.uri,
                                options = job.options,
                                outputFile = outputFile,
                                onProgress = { p -> onProgressUpdate(p, "Formatting PDF (${(p * 100).toInt()}%)") }
                            )
                        }
                        targetExt == "html" && inputExt in listOf("txt", "md", "csv", "log") -> {
                            DocumentConversionEngine.convertTxtToHtml(
                                context = context,
                                inputUri = originalInfo.uri,
                                outputFile = outputFile,
                                onProgress = { p -> onProgressUpdate(p, "Generating HTML...") }
                            )
                        }
                        targetExt == "txt" && inputExt in listOf("html", "htm") -> {
                            DocumentConversionEngine.convertHtmlToTxt(
                                context = context,
                                inputUri = originalInfo.uri,
                                outputFile = outputFile,
                                onProgress = { p -> onProgressUpdate(p, "Extracting text...") }
                            )
                        }
                        targetExt == "zip" -> {
                            ArchiveEngine.createZipFromUris(
                                context = context,
                                uris = listOf(Pair(originalInfo.uri, originalInfo.name)),
                                outputZipFile = outputFile,
                                onProgress = { p -> onProgressUpdate(p, "Compressing to ZIP...") }
                            )
                        }
                        else -> {
                            throw UnsupportedOperationException("Conversion from .${originalInfo.extension} to .$targetExt is not supported")
                        }
                    }
                }

                FileCategory.AUDIO -> {
                    if (targetExt == "wav") {
                        AudioConversionEngine.convertAudioToWav(
                            context = context,
                            inputUri = originalInfo.uri,
                            options = job.options,
                            outputFile = outputFile,
                            onProgress = { p -> onProgressUpdate(p, "Decoding & rendering WAV (${(p * 100).toInt()}%)") }
                        )
                    } else if (targetExt == "zip") {
                        ArchiveEngine.createZipFromUris(
                            context = context,
                            uris = listOf(Pair(originalInfo.uri, originalInfo.name)),
                            outputZipFile = outputFile,
                            onProgress = { p -> onProgressUpdate(p, "Compressing...") }
                        )
                    } else {
                        throw UnsupportedOperationException("Audio target .$targetExt conversion requires WAV container")
                    }
                }

                FileCategory.VIDEO -> {
                    when (targetExt) {
                        "wav" -> {
                            VideoConversionEngine.extractAudioFromVideo(
                                context = context,
                                inputUri = originalInfo.uri,
                                options = job.options,
                                outputFile = outputFile,
                                onProgress = { p -> onProgressUpdate(p, "Extracting audio track (${(p * 100).toInt()}%)") }
                            )
                        }
                        "jpg", "jpeg", "png", "webp" -> {
                            VideoConversionEngine.extractKeyframe(
                                context = context,
                                inputUri = originalInfo.uri,
                                targetExtension = targetExt,
                                options = job.options,
                                outputFile = outputFile,
                                onProgress = { p -> onProgressUpdate(p, "Extracting video keyframe...") }
                            )
                        }
                        "zip" -> {
                            ArchiveEngine.createZipFromUris(
                                context = context,
                                uris = listOf(Pair(originalInfo.uri, originalInfo.name)),
                                outputZipFile = outputFile,
                                onProgress = { p -> onProgressUpdate(p, "Packaging video to ZIP...") }
                            )
                        }
                        else -> {
                            throw UnsupportedOperationException("Unsupported video export target: $targetExt")
                        }
                    }
                }

                FileCategory.ARCHIVE, FileCategory.OTHER -> {
                    ArchiveEngine.createZipFromUris(
                        context = context,
                        uris = listOf(Pair(originalInfo.uri, originalInfo.name)),
                        outputZipFile = outputFile,
                        onProgress = { p -> onProgressUpdate(p, "Packaging file (${(p * 100).toInt()}%)") }
                    )
                }
            }

            val endTime = System.currentTimeMillis()
            val duration = endTime - startTime
            val convertedSize = if (outputFile.exists()) outputFile.length() else 0L

            val completedJob = job.copy(
                status = JobStatus.COMPLETED,
                progress = 1.0f,
                statusMessage = "Conversion Complete",
                convertedFile = outputFile,
                convertedSizeBytes = convertedSize,
                durationMs = duration
            )

            // Save to Room DB history
            historyRepository.insert(
                ConversionHistoryEntity(
                    fileName = originalInfo.name,
                    outputFileName = outputFile.name,
                    originalFormat = originalInfo.extension.uppercase(),
                    targetFormat = targetExt.uppercase(),
                    category = originalInfo.category.name,
                    originalSizeBytes = originalInfo.sizeBytes,
                    convertedSizeBytes = convertedSize,
                    durationMs = duration,
                    status = "COMPLETED",
                    outputFilePath = outputFile.absolutePath
                )
            )

            completedJob
        } catch (e: Exception) {
            val endTime = System.currentTimeMillis()
            val failedJob = job.copy(
                status = JobStatus.FAILED,
                progress = 0f,
                statusMessage = "Conversion Failed",
                errorMessage = e.localizedMessage ?: "Unknown conversion error",
                durationMs = endTime - startTime
            )

            // Record failed conversion in Room DB
            historyRepository.insert(
                ConversionHistoryEntity(
                    fileName = originalInfo.name,
                    outputFileName = outputName,
                    originalFormat = originalInfo.extension.uppercase(),
                    targetFormat = targetExt.uppercase(),
                    category = originalInfo.category.name,
                    originalSizeBytes = originalInfo.sizeBytes,
                    convertedSizeBytes = 0L,
                    durationMs = endTime - startTime,
                    status = "FAILED",
                    errorMessage = e.localizedMessage ?: "Error during processing"
                )
            )

            failedJob
        }
    }

    fun clearTemporaryCache(): Long {
        var freedBytes = 0L
        if (conversionDir.exists()) {
            conversionDir.listFiles()?.forEach { file ->
                freedBytes += file.length()
                file.delete()
            }
        }
        return freedBytes
    }

    fun getCacheSizeBytes(): Long {
        var total = 0L
        if (conversionDir.exists()) {
            conversionDir.listFiles()?.forEach { file ->
                total += file.length()
            }
        }
        return total
    }
}
