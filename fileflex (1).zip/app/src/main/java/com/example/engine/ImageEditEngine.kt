package com.example.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.net.Uri
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

data class ImageAdjustmentState(
    val brightness: Float = 0f,    // -100 to +100
    val contrast: Float = 0f,      // -100 to +100
    val saturation: Float = 0f,    // -100 to +100
    val exposure: Float = 0f,      // -100 to +100
    val isGrayscale: Boolean = false,
    val isSepia: Boolean = false,
    val isInverted: Boolean = false,
    val rotationDegrees: Float = 0f,
    val flipHorizontal: Boolean = false,
    val flipVertical: Boolean = false,
    val blurRadius: Int = 0,       // 0 to 25
    val watermarkText: String = "",
    val watermarkOpacity: Float = 0.5f,
    val targetWidth: Int? = null,
    val targetHeight: Int? = null,
    val exportFormat: String = "jpg", // jpg, png, webp, bmp
    val exportQuality: Int = 90
)

data class ImageDrawStroke(
    val points: List<Pair<Float, Float>>,
    val color: Int,
    val strokeWidth: Float,
    val isEraser: Boolean = false
)

data class ImageTextItem(
    val text: String,
    val x: Float,
    val y: Float,
    val color: Int = Color.WHITE,
    val textSize: Float = 36f
)

object ImageEditEngine {

    fun loadBitmapFromUri(context: Context, uri: Uri, maxDimension: Int = 2048): Bitmap? {
        return try {
            val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.contentResolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, options)
            }

            var inSampleSize = 1
            val origW = options.outWidth
            val origH = options.outHeight

            if (origW > maxDimension || origH > maxDimension) {
                val halfW = origW / 2
                val halfH = origH / 2
                while ((halfW / inSampleSize) >= maxDimension && (halfH / inSampleSize) >= maxDimension) {
                    inSampleSize *= 2
                }
            }

            val decodeOptions = BitmapFactory.Options().apply {
                this.inSampleSize = inSampleSize
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }

            context.contentResolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, decodeOptions)
            }
        } catch (e: Exception) {
            null
        }
    }

    suspend fun applyEditsAndExport(
        sourceBitmap: Bitmap,
        adjustments: ImageAdjustmentState,
        strokes: List<ImageDrawStroke> = emptyList(),
        textItems: List<ImageTextItem> = emptyList(),
        cropRect: Rect? = null,
        outputFile: File
    ): File = withContext(Dispatchers.IO) {
        var baseBitmap = sourceBitmap

        // 1. Crop if specified
        if (cropRect != null && cropRect.width() > 0 && cropRect.height() > 0) {
            val safeLeft = cropRect.left.coerceIn(0, baseBitmap.width - 1)
            val safeTop = cropRect.top.coerceIn(0, baseBitmap.height - 1)
            val safeWidth = cropRect.width().coerceAtMost(baseBitmap.width - safeLeft)
            val safeHeight = cropRect.height().coerceAtMost(baseBitmap.height - safeTop)
            baseBitmap = Bitmap.createBitmap(baseBitmap, safeLeft, safeTop, safeWidth, safeHeight)
        }

        // 2. Resize if requested
        if (adjustments.targetWidth != null && adjustments.targetHeight != null &&
            adjustments.targetWidth > 0 && adjustments.targetHeight > 0
        ) {
            val scaled = Bitmap.createScaledBitmap(baseBitmap, adjustments.targetWidth, adjustments.targetHeight, true)
            if (scaled != baseBitmap && baseBitmap != sourceBitmap) baseBitmap.recycle()
            baseBitmap = scaled
        }

        // 3. Transformation matrix (Rotation & Flipping)
        val matrix = Matrix()
        if (adjustments.rotationDegrees % 360 != 0f) {
            matrix.postRotate(adjustments.rotationDegrees)
        }
        val sx = if (adjustments.flipHorizontal) -1f else 1f
        val sy = if (adjustments.flipVertical) -1f else 1f
        if (sx != 1f || sy != 1f) {
            matrix.postScale(sx, sy)
        }

        val transformedBitmap = if (!matrix.isIdentity) {
            Bitmap.createBitmap(baseBitmap, 0, 0, baseBitmap.width, baseBitmap.height, matrix, true)
        } else {
            baseBitmap.copy(Bitmap.Config.ARGB_8888, true)
        }

        // 4. Color adjustments (Brightness, Contrast, Saturation, Sepia, Invert, Grayscale)
        val resultBitmap = Bitmap.createBitmap(transformedBitmap.width, transformedBitmap.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(resultBitmap)

        val colorMatrix = ColorMatrix()
        applyColorAdjustments(colorMatrix, adjustments)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(colorMatrix)
        }
        canvas.drawBitmap(transformedBitmap, 0f, 0f, paint)

        // 5. Apply Fast Box Blur if set
        if (adjustments.blurRadius > 0) {
            fastBlur(resultBitmap, adjustments.blurRadius.coerceIn(1, 20))
        }

        // 6. Draw User Strokes (Freehand drawings)
        val drawCanvas = Canvas(resultBitmap)
        for (stroke in strokes) {
            if (stroke.points.size > 1) {
                val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = if (stroke.isEraser) Color.WHITE else stroke.color
                    strokeWidth = stroke.strokeWidth
                    style = Paint.Style.STROKE
                    strokeCap = Paint.Cap.ROUND
                    strokeJoin = Paint.Join.ROUND
                }
                val path = android.graphics.Path()
                val first = stroke.points.first()
                path.moveTo(first.first, first.second)
                for (i in 1 until stroke.points.size) {
                    val pt = stroke.points[i]
                    path.lineTo(pt.first, pt.second)
                }
                drawCanvas.drawPath(path, strokePaint)
            }
        }

        // 7. Draw Custom Text Items
        for (item in textItems) {
            val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = item.color
                textSize = item.textSize
                setShadowLayer(4f, 2f, 2f, Color.BLACK)
            }
            drawCanvas.drawText(item.text, item.x, item.y, textPaint)
        }

        // 8. Draw Watermark if configured
        if (adjustments.watermarkText.isNotBlank()) {
            val wmPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                alpha = (adjustments.watermarkOpacity * 255).toInt().coerceIn(0, 255)
                textSize = (resultBitmap.width * 0.04f).coerceIn(24f, 72f)
                setShadowLayer(6f, 2f, 2f, Color.BLACK)
            }
            val textWidth = wmPaint.measureText(adjustments.watermarkText)
            val wmX = resultBitmap.width - textWidth - 30f
            val wmY = resultBitmap.height - 30f
            drawCanvas.drawText(adjustments.watermarkText, wmX, wmY, wmPaint)
        }

        // 9. Compress and save to requested format
        val ext = adjustments.exportFormat.lowercase().trimStart('.')
        val fos = FileOutputStream(outputFile)
        try {
            when (ext) {
                "png" -> {
                    resultBitmap.compress(Bitmap.CompressFormat.PNG, 100, fos)
                }
                "webp" -> {
                    val format = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        if (adjustments.exportQuality >= 100) Bitmap.CompressFormat.WEBP_LOSSLESS else Bitmap.CompressFormat.WEBP_LOSSY
                    } else {
                        @Suppress("DEPRECATION")
                        Bitmap.CompressFormat.WEBP
                    }
                    resultBitmap.compress(format, adjustments.exportQuality.coerceIn(1, 100), fos)
                }
                "bmp" -> {
                    writeBmp(resultBitmap, fos)
                }
                else -> { // jpg / jpeg
                    val flat = flattenOnWhite(resultBitmap)
                    flat.compress(Bitmap.CompressFormat.JPEG, adjustments.exportQuality.coerceIn(1, 100), fos)
                    if (flat != resultBitmap) flat.recycle()
                }
            }
            fos.flush()
        } finally {
            fos.close()
            resultBitmap.recycle()
            if (transformedBitmap != baseBitmap) transformedBitmap.recycle()
            if (baseBitmap != sourceBitmap) baseBitmap.recycle()
        }

        outputFile
    }

    private fun applyColorAdjustments(matrix: ColorMatrix, state: ImageAdjustmentState) {
        // Brightness & Exposure
        val totalBrightness = (state.brightness + state.exposure).coerceIn(-100f, 100f) * 1.5f
        val brightnessMatrix = ColorMatrix(
            floatArrayOf(
                1f, 0f, 0f, 0f, totalBrightness,
                0f, 1f, 0f, 0f, totalBrightness,
                0f, 0f, 1f, 0f, totalBrightness,
                0f, 0f, 0f, 1f, 0f
            )
        )
        matrix.postConcat(brightnessMatrix)

        // Contrast
        if (state.contrast != 0f) {
            val scale = (state.contrast + 100f) / 100f
            val translate = (-0.5f * scale + 0.5f) * 255f
            val contrastMatrix = ColorMatrix(
                floatArrayOf(
                    scale, 0f, 0f, 0f, translate,
                    0f, scale, 0f, 0f, translate,
                    0f, 0f, scale, 0f, translate,
                    0f, 0f, 0f, 1f, 0f
                )
            )
            matrix.postConcat(contrastMatrix)
        }

        // Saturation
        if (state.saturation != 0f) {
            val sat = (state.saturation + 100f) / 100f
            val satMatrix = ColorMatrix()
            satMatrix.setSaturation(sat)
            matrix.postConcat(satMatrix)
        }

        // Grayscale
        if (state.isGrayscale) {
            val grayMatrix = ColorMatrix()
            grayMatrix.setSaturation(0f)
            matrix.postConcat(grayMatrix)
        }

        // Sepia
        if (state.isSepia) {
            val sepiaMatrix = ColorMatrix(
                floatArrayOf(
                    0.393f, 0.769f, 0.189f, 0f, 0f,
                    0.349f, 0.686f, 0.168f, 0f, 0f,
                    0.272f, 0.534f, 0.131f, 0f, 0f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
            matrix.postConcat(sepiaMatrix)
        }

        // Invert
        if (state.isInverted) {
            val invertMatrix = ColorMatrix(
                floatArrayOf(
                    -1f, 0f, 0f, 0f, 255f,
                    0f, -1f, 0f, 0f, 255f,
                    0f, 0f, -1f, 0f, 255f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
            matrix.postConcat(invertMatrix)
        }
    }

    private fun flattenOnWhite(src: Bitmap): Bitmap {
        if (!src.hasAlpha()) return src
        val result = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        canvas.drawColor(Color.WHITE)
        canvas.drawBitmap(src, 0f, 0f, Paint(Paint.FILTER_BITMAP_FLAG))
        return result
    }

    private fun writeBmp(bitmap: Bitmap, outputStream: FileOutputStream) {
        val width = bitmap.width
        val height = bitmap.height
        val rowPadding = (4 - (width * 3) % 4) % 4
        val imageSize = (width * 3 + rowPadding) * height
        val fileSize = 54 + imageSize

        val header = ByteBuffer.allocate(54).order(ByteOrder.LITTLE_ENDIAN)
        header.put('B'.code.toByte())
        header.put('M'.code.toByte())
        header.putInt(fileSize)
        header.putShort(0)
        header.putShort(0)
        header.putInt(54)

        header.putInt(40)
        header.putInt(width)
        header.putInt(height)
        header.putShort(1)
        header.putShort(24)
        header.putInt(0)
        header.putInt(imageSize)
        header.putInt(2835)
        header.putInt(2835)
        header.putInt(0)
        header.putInt(0)

        outputStream.write(header.array())

        val pixels = IntArray(width)
        val rowBuffer = ByteArray(width * 3 + rowPadding)

        for (y in height - 1 downTo 0) {
            bitmap.getPixels(pixels, 0, width, 0, y, width, 1)
            var bufferIndex = 0
            for (x in 0 until width) {
                val color = pixels[x]
                rowBuffer[bufferIndex++] = (color and 0xFF).toByte()
                rowBuffer[bufferIndex++] = ((color shr 8) and 0xFF).toByte()
                rowBuffer[bufferIndex++] = ((color shr 16) and 0xFF).toByte()
            }
            for (p in 0 until rowPadding) {
                rowBuffer[bufferIndex++] = 0
            }
            outputStream.write(rowBuffer, 0, bufferIndex)
        }
    }

    private fun fastBlur(sentBitmap: Bitmap, radius: Int) {
        val w = sentBitmap.width
        val h = sentBitmap.height
        val pix = IntArray(w * h)
        sentBitmap.getPixels(pix, 0, w, 0, 0, w, h)

        val wm = w - 1
        val hm = h - 1
        val wh = w * h
        val div = radius + radius + 1

        val r = IntArray(wh)
        val g = IntArray(wh)
        val b = IntArray(wh)
        var rsum: Int
        var gsum: Int
        var bsum: Int
        var x: Int
        var y: Int
        var i: Int
        var p: Int
        var yp: Int
        var yi: Int
        var yw: Int
        val vmin = IntArray(Math.max(w, h))

        var divsum = (div + 1) shr 1
        divsum *= divsum
        val dv = IntArray(256 * divsum)
        i = 0
        while (i < 256 * divsum) {
            dv[i] = i / divsum
            i++
        }

        yw = 0
        yi = 0

        val stack = Array(div) { IntArray(3) }
        var stackpointer: Int
        var stackstart: Int
        var sir: IntArray
        var rbs: Int
        val r1 = radius + 1
        var routsum: Int
        var goutsum: Int
        var boutsum: Int
        var rinsum: Int
        var ginsum: Int
        var binsum: Int

        y = 0
        while (y < h) {
            rinsum = 0
            ginsum = 0
            binsum = 0
            routsum = 0
            goutsum = 0
            boutsum = 0
            rsum = 0
            gsum = 0
            bsum = 0
            i = -radius
            while (i <= radius) {
                p = pix[yi + Math.min(wm, Math.max(i, 0))]
                sir = stack[i + radius]
                sir[0] = p and 0xff0000 shr 16
                sir[1] = p and 0x00ff00 shr 8
                sir[2] = p and 0x0000ff
                rbs = r1 - Math.abs(i)
                rsum += sir[0] * rbs
                gsum += sir[1] * rbs
                bsum += sir[2] * rbs
                if (i > 0) {
                    rinsum += sir[0]
                    ginsum += sir[1]
                    binsum += sir[2]
                } else {
                    routsum += sir[0]
                    goutsum += sir[1]
                    boutsum += sir[2]
                }
                i++
            }
            stackpointer = radius

            x = 0
            while (x < w) {
                r[yi] = dv[rsum]
                g[yi] = dv[gsum]
                b[yi] = dv[bsum]

                rsum -= routsum
                gsum -= goutsum
                bsum -= boutsum

                stackstart = stackpointer - radius + div
                sir = stack[stackstart % div]

                routsum -= sir[0]
                goutsum -= sir[1]
                boutsum -= sir[2]

                if (y == 0) {
                    vmin[x] = Math.min(x + radius + 1, wm)
                }
                p = pix[yw + vmin[x]]

                sir[0] = p and 0xff0000 shr 16
                sir[1] = p and 0x00ff00 shr 8
                sir[2] = p and 0x0000ff

                rinsum += sir[0]
                ginsum += sir[1]
                binsum += sir[2]

                rsum += rinsum
                gsum += ginsum
                bsum += binsum

                stackpointer = (stackpointer + 1) % div
                sir = stack[stackpointer % div]

                routsum += sir[0]
                goutsum += sir[1]
                boutsum += sir[2]

                rinsum -= sir[0]
                ginsum -= sir[1]
                binsum -= sir[2]

                yi++
                x++
            }
            yw += w
            y++
        }
        x = 0
        while (x < w) {
            rinsum = 0
            ginsum = 0
            binsum = 0
            routsum = 0
            goutsum = 0
            boutsum = 0
            rsum = 0
            gsum = 0
            bsum = 0
            yp = -radius * w
            i = -radius
            while (i <= radius) {
                yi = Math.max(0, yp) + x
                sir = stack[i + radius]
                sir[0] = r[yi]
                sir[1] = g[yi]
                sir[2] = b[yi]
                rbs = r1 - Math.abs(i)
                rsum += r[yi] * rbs
                gsum += g[yi] * rbs
                bsum += b[yi] * rbs
                if (i > 0) {
                    rinsum += sir[0]
                    ginsum += sir[1]
                    binsum += sir[2]
                } else {
                    routsum += sir[0]
                    goutsum += sir[1]
                    boutsum += sir[2]
                }
                if (i < hm) {
                    yp += w
                }
                i++
            }
            yi = x
            stackpointer = radius
            y = 0
            while (y < h) {
                pix[yi] = -0x1000000 and pix[yi] or (dv[rsum] shl 16) or (dv[gsum] shl 8) or dv[bsum]

                rsum -= routsum
                gsum -= goutsum
                bsum -= boutsum

                stackstart = stackpointer - radius + div
                sir = stack[stackstart % div]

                routsum -= sir[0]
                goutsum -= sir[1]
                boutsum -= sir[2]

                if (x == 0) {
                    vmin[y] = Math.min(y + r1, hm) * w
                }
                p = x + vmin[y]

                sir[0] = r[p]
                sir[1] = g[p]
                sir[2] = b[p]

                rinsum += sir[0]
                ginsum += sir[1]
                binsum += sir[2]

                rsum += rinsum
                gsum += ginsum
                bsum += binsum

                stackpointer = (stackpointer + 1) % div
                sir = stack[stackpointer]

                routsum += sir[0]
                goutsum += sir[1]
                boutsum += sir[2]

                rinsum -= sir[0]
                ginsum -= sir[1]
                binsum -= sir[2]

                yi += w
                y++
            }
            x++
        }
        sentBitmap.setPixels(pix, 0, w, 0, 0, w, h)
    }
}
