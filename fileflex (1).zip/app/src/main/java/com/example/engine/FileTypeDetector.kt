package com.example.engine

import android.content.Context
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import com.example.model.FileCategory
import com.example.model.FileInfo
import java.io.InputStream

object FileTypeDetector {

    fun detectFileInfo(context: Context, uri: Uri): FileInfo {
        var name = "unknown_file"
        var sizeBytes = 0L

        // Resolve display name and size from content resolver
        try {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (nameIndex != -1) {
                        name = cursor.getString(nameIndex) ?: name
                    }
                    if (sizeIndex != -1) {
                        sizeBytes = cursor.getLong(sizeIndex)
                    }
                }
            }
        } catch (_: Exception) {}

        val ext = if (name.contains('.')) name.substringAfterLast('.').lowercase() else ""
        var mimeType = context.contentResolver.getType(uri) ?: ""
        if (mimeType.isBlank() && ext.isNotBlank()) {
            mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: ""
        }

        val category = determineCategory(ext, mimeType)
        var imageWidth = 0
        var imageHeight = 0
        var mediaDurationMs = 0L
        var isTextPreviewable = false
        var textSample: String? = null

        when (category) {
            FileCategory.IMAGE -> {
                try {
                    context.contentResolver.openInputStream(uri)?.use { stream ->
                        val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                        BitmapFactory.decodeStream(stream, null, options)
                        imageWidth = options.outWidth
                        imageHeight = options.outHeight
                    }
                } catch (_: Exception) {}
            }
            FileCategory.AUDIO, FileCategory.VIDEO -> {
                try {
                    val retriever = MediaMetadataRetriever()
                    retriever.setDataSource(context, uri)
                    val durStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                    mediaDurationMs = durStr?.toLongOrNull() ?: 0L

                    if (category == FileCategory.VIDEO) {
                        val wStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
                        val hStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
                        imageWidth = wStr?.toIntOrNull() ?: 0
                        imageHeight = hStr?.toIntOrNull() ?: 0
                    }
                    retriever.release()
                } catch (_: Exception) {}
            }
            FileCategory.DOCUMENT -> {
                if (ext in listOf("txt", "html", "htm", "md", "csv", "json", "xml", "log")) {
                    isTextPreviewable = true
                    try {
                        context.contentResolver.openInputStream(uri)?.use { stream ->
                            val buffer = ByteArray(2048)
                            val read = stream.read(buffer)
                            if (read > 0) {
                                textSample = String(buffer, 0, read, Charsets.UTF_8)
                            }
                        }
                    } catch (_: Exception) {}
                }
            }
            else -> {}
        }

        return FileInfo(
            uri = uri,
            name = name,
            extension = ext,
            sizeBytes = sizeBytes,
            mimeType = mimeType,
            category = category,
            imageWidth = imageWidth,
            imageHeight = imageHeight,
            mediaDurationMs = mediaDurationMs,
            isTextPreviewable = isTextPreviewable,
            textSample = textSample
        )
    }

    private fun determineCategory(extension: String, mimeType: String): FileCategory {
        val ext = extension.lowercase()
        val mime = mimeType.lowercase()

        return when {
            mime.startsWith("image/") || ext in listOf("jpg", "jpeg", "png", "webp", "gif", "bmp", "ico", "tiff", "tif", "svg", "heic", "heif", "avif") -> FileCategory.IMAGE
            mime.startsWith("audio/") || ext in listOf("mp3", "wav", "m4a", "aac", "ogg", "flac", "wma", "opus", "amr") -> FileCategory.AUDIO
            mime.startsWith("video/") || ext in listOf("mp4", "mkv", "avi", "mov", "webm", "flv", "3gp", "ts") -> FileCategory.VIDEO
            mime.contains("zip") || mime.contains("compressed") || ext in listOf("zip", "rar", "7z", "tar", "gz") -> FileCategory.ARCHIVE
            mime.startsWith("text/") || mime.contains("pdf") || ext in listOf("txt", "pdf", "html", "htm", "md", "doc", "docx", "csv", "json", "xml", "log") -> FileCategory.DOCUMENT
            else -> FileCategory.OTHER
        }
    }
}
