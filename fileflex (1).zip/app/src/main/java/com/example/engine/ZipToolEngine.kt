package com.example.engine

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

data class ZipEntryItem(
    val name: String,
    val sizeBytes: Long,
    val compressedSizeBytes: Long,
    val isDirectory: Boolean
) {
    val formattedSize: String
        get() = when {
            sizeBytes >= 1024 * 1024 -> String.format("%.2f MB", sizeBytes / (1024.0 * 1024.0))
            sizeBytes >= 1024 -> String.format("%.1f KB", sizeBytes / 1024.0)
            else -> "$sizeBytes B"
        }
}

object ZipToolEngine {

    suspend fun listZipEntries(context: Context, zipUri: Uri): List<ZipEntryItem> = withContext(Dispatchers.IO) {
        val entries = mutableListOf<ZipEntryItem>()
        context.contentResolver.openInputStream(zipUri)?.use { inputStream ->
            ZipInputStream(inputStream).use { zis ->
                var entry: ZipEntry? = zis.nextEntry
                while (entry != null) {
                    entries.add(
                        ZipEntryItem(
                            name = entry.name,
                            sizeBytes = if (entry.size >= 0) entry.size else 0L,
                            compressedSizeBytes = if (entry.compressedSize >= 0) entry.compressedSize else 0L,
                            isDirectory = entry.isDirectory
                        )
                    )
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
        }
        entries
    }

    suspend fun extractZip(
        context: Context,
        zipUri: Uri,
        destDir: File,
        onProgress: (Float) -> Unit
    ): List<File> = withContext(Dispatchers.IO) {
        if (!destDir.exists()) destDir.mkdirs()
        val extractedFiles = mutableListOf<File>()

        context.contentResolver.openInputStream(zipUri)?.use { inputStream ->
            ZipInputStream(inputStream).use { zis ->
                val buffer = ByteArray(8192)
                var entry: ZipEntry? = zis.nextEntry
                while (entry != null) {
                    val newFile = File(destDir, entry.name)
                    if (entry.isDirectory) {
                        newFile.mkdirs()
                    } else {
                        newFile.parentFile?.mkdirs()
                        FileOutputStream(newFile).use { fos ->
                            var len: Int
                            while (zis.read(buffer).also { len = it } > 0) {
                                fos.write(buffer, 0, len)
                            }
                        }
                        extractedFiles.add(newFile)
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
        }
        onProgress(1.0f)
        extractedFiles
    }

    suspend fun createZipFromFiles(
        files: List<File>,
        outputZipFile: File,
        onProgress: (Float) -> Unit
    ): File = withContext(Dispatchers.IO) {
        ArchiveEngine.createZipFromFiles(files, outputZipFile, onProgress)
    }

    suspend fun createZipFromUris(
        context: Context,
        uris: List<Pair<Uri, String>>,
        outputZipFile: File,
        onProgress: (Float) -> Unit
    ): File = withContext(Dispatchers.IO) {
        ArchiveEngine.createZipFromUris(context, uris, outputZipFile, onProgress)
    }
}
