package com.example.engine

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer

data class VideoEditParams(
    val startMs: Long = 0L,
    val endMs: Long = 0L,
    val extractAudio: Boolean = false,
    val extractFrameSecond: Float = 0f
)

object VideoEditEngine {

    /**
     * Lossless fast video trimmer using Android native MediaExtractor and MediaMuxer.
     */
    suspend fun trimVideo(
        context: Context,
        inputUri: Uri,
        startMs: Long,
        endMs: Long,
        outputFile: File,
        onProgress: (Float) -> Unit
    ): File = withContext(Dispatchers.IO) {
        onProgress(0.05f)

        val extractor = MediaExtractor()
        extractor.setDataSource(context, inputUri, null)

        val muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val trackCount = extractor.trackCount
        val indexMap = HashMap<Int, Int>(trackCount)
        val bufferSize = 1024 * 1024
        val buffer = ByteBuffer.allocate(bufferSize)
        val bufferInfo = MediaCodec.BufferInfo()

        val startUs = startMs * 1000L
        val endUs = if (endMs > 0) endMs * 1000L else Long.MAX_VALUE

        try {
            for (i in 0 until trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("video/") || mime.startsWith("audio/")) {
                    extractor.selectTrack(i)
                    val dstIndex = muxer.addTrack(format)
                    indexMap[i] = dstIndex
                }
            }

            muxer.start()

            if (startUs > 0) {
                extractor.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
            }

            var sampleCount = 0
            while (true) {
                val trackIndex = extractor.sampleTrackIndex
                if (trackIndex < 0) break

                val dstIndex = indexMap[trackIndex]
                if (dstIndex != null) {
                    bufferInfo.offset = 0
                    bufferInfo.size = extractor.readSampleData(buffer, 0)
                    if (bufferInfo.size < 0) break

                    bufferInfo.presentationTimeUs = extractor.sampleTime
                    bufferInfo.flags = extractor.sampleFlags

                    if (bufferInfo.presentationTimeUs >= startUs) {
                        if (bufferInfo.presentationTimeUs > endUs) break
                        muxer.writeSampleData(dstIndex, buffer, bufferInfo)
                    }
                }

                sampleCount++
                if (sampleCount % 100 == 0) {
                    val p = if (endUs > startUs) {
                        ((extractor.sampleTime - startUs).toFloat() / (endUs - startUs).toFloat()).coerceIn(0f, 0.95f)
                    } else 0.5f
                    onProgress(p)
                }

                extractor.advance()
            }
        } finally {
            try { muxer.stop() } catch (_: Exception) {}
            try { muxer.release() } catch (_: Exception) {}
            try { extractor.release() } catch (_: Exception) {}
        }

        onProgress(1.0f)
        outputFile
    }

    /**
     * Extracts audio stream directly from MP4/video into an M4A file without quality loss.
     */
    suspend fun extractAudioStreamToM4a(
        context: Context,
        inputUri: Uri,
        outputFile: File,
        onProgress: (Float) -> Unit
    ): File = withContext(Dispatchers.IO) {
        onProgress(0.1f)
        val extractor = MediaExtractor()
        extractor.setDataSource(context, inputUri, null)

        var audioTrackIndex = -1
        var audioFormat: MediaFormat? = null

        for (i in 0 until extractor.trackCount) {
            val format = extractor.getTrackFormat(i)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
            if (mime.startsWith("audio/")) {
                audioTrackIndex = i
                audioFormat = format
                break
            }
        }

        if (audioTrackIndex == -1 || audioFormat == null) {
            extractor.release()
            throw IllegalArgumentException("No audio track found in this video")
        }

        extractor.selectTrack(audioTrackIndex)
        val muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val dstIndex = muxer.addTrack(audioFormat)
        muxer.start()

        val buffer = ByteBuffer.allocate(512 * 1024)
        val bufferInfo = MediaCodec.BufferInfo()

        try {
            while (true) {
                bufferInfo.offset = 0
                bufferInfo.size = extractor.readSampleData(buffer, 0)
                if (bufferInfo.size < 0) break

                bufferInfo.presentationTimeUs = extractor.sampleTime
                bufferInfo.flags = extractor.sampleFlags
                muxer.writeSampleData(dstIndex, buffer, bufferInfo)
                extractor.advance()
            }
        } finally {
            try { muxer.stop() } catch (_: Exception) {}
            try { muxer.release() } catch (_: Exception) {}
            try { extractor.release() } catch (_: Exception) {}
        }

        onProgress(1.0f)
        outputFile
    }

    /**
     * Extracts frame from video at timestamp in seconds.
     */
    fun extractFrameAtTime(
        context: Context,
        inputUri: Uri,
        timeSeconds: Float,
        targetFormat: String = "jpg",
        outputFile: File
    ): File {
        val retriever = MediaMetadataRetriever()
        retriever.setDataSource(context, inputUri)

        val timeUs = (timeSeconds * 1000000L).toLong()
        val frame = retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
            ?: retriever.frameAtTime
            ?: throw IllegalStateException("Failed to extract frame")

        retriever.release()

        val fos = FileOutputStream(outputFile)
        val ext = targetFormat.lowercase().trimStart('.')
        when (ext) {
            "png" -> frame.compress(Bitmap.CompressFormat.PNG, 100, fos)
            "webp" -> frame.compress(Bitmap.CompressFormat.WEBP, 90, fos)
            else -> frame.compress(Bitmap.CompressFormat.JPEG, 90, fos)
        }
        fos.flush()
        fos.close()
        frame.recycle()
        return outputFile
    }
}
