package com.example.engine

import java.io.File

object SafeFileNameGenerator {
    private val ILLEGAL_CHARACTERS = Regex("[/\\\\:*?\"<>|\\x00-\\x1F]")

    fun sanitizeBaseName(rawName: String): String {
        val nameWithoutExt = rawName.substringBeforeLast('.')
        var clean = nameWithoutExt.replace(ILLEGAL_CHARACTERS, "_").trim()
        if (clean.isBlank()) {
            clean = "converted_file"
        }
        // Truncate to reasonable length to prevent filesystem limits
        if (clean.length > 80) {
            clean = clean.substring(0, 80)
        }
        return clean
    }

    fun generateOutputFileName(
        originalName: String,
        targetExtension: String,
        destinationDir: File? = null
    ): String {
        val baseName = sanitizeBaseName(originalName)
        val ext = targetExtension.lowercase().trimStart('.')
        val candidate = "$baseName.$ext"

        if (destinationDir == null || !File(destinationDir, candidate).exists()) {
            return candidate
        }

        var index = 1
        var uniqueName = "${baseName}_$index.$ext"
        while (File(destinationDir, uniqueName).exists()) {
            index++
            uniqueName = "${baseName}_$index.$ext"
        }
        return uniqueName
    }
}
