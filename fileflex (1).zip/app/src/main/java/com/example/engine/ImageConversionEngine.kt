package com.example.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.net.Uri
import android.os.Build
import com.example.model.ConversionOptions
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

object ImageConversionEngine {

    fun convertImage(
        context: Context,
        inputUri: Uri,
        targetExtension: String,
        options: ConversionOptions,
        outputFile: File,
        onProgress: (Float) -> Unit
    ): File {
        onProgress(0.1f)

        // 1. Decode original Bitmap
        val inputStream = context.contentResolver.openInputStream(inputUri)
            ?: throw IllegalArgumentException("Cannot open input file stream")

        val originalBitmap = inputStream.use { stream ->
            BitmapFactory.decodeStream(stream)
        } ?: throw IllegalStateException("Failed to decode image data")

        onProgress(0.4f)

        // 2. Apply Resizing if configured
        val processedBitmap = processBitmap(originalBitmap, options)
        onProgress(0.6f)

        val targetExt = targetExtension.lowercase().trimStart('.')
        val fos = FileOutputStream(outputFile)

        try {
            when (targetExt) {
                "jpg", "jpeg" -> {
                    // Flatten transparency on white background
                    val flatBitmap = flattenTransparency(processedBitmap, options.backgroundColor)
                    flatBitmap.compress(Bitmap.CompressFormat.JPEG, options.imageQuality.coerceIn(1, 100), fos)
                    if (flatBitmap != processedBitmap) flatBitmap.recycle()
                }
                "png" -> {
                    processedBitmap.compress(Bitmap.CompressFormat.PNG, 100, fos)
                }
                "webp" -> {
                    val format = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        if (options.imageQuality >= 100) {
                            Bitmap.CompressFormat.WEBP_LOSSLESS
                        } else {
                            Bitmap.CompressFormat.WEBP_LOSSY
                        }
                    } else {
                        @Suppress("DEPRECATION")
                        Bitmap.CompressFormat.WEBP
                    }
                    processedBitmap.compress(format, options.imageQuality.coerceIn(1, 100), fos)
                }
                "bmp" -> {
                    val flatBitmap = if (options.removeTransparency) {
                        flattenTransparency(processedBitmap, options.backgroundColor)
                    } else {
                        processedBitmap
                    }
                    writeBmp(flatBitmap, fos)
                    if (flatBitmap != processedBitmap) flatBitmap.recycle()
                }
                "ico" -> {
                    // Standard Windows ICO format embedding PNG data
                    writeIco(processedBitmap, fos)
                }
                else -> {
                    throw UnsupportedOperationException("Unsupported target image format: $targetExt")
                }
            }
            fos.flush()
        } finally {
            fos.close()
            if (processedBitmap != originalBitmap) {
                processedBitmap.recycle()
            }
            originalBitmap.recycle()
        }

        onProgress(1.0f)
        return outputFile
    }

    private fun processBitmap(src: Bitmap, options: ConversionOptions): Bitmap {
        var targetWidth = src.width
        var targetHeight = src.height

        if (options.customWidth != null && options.customWidth > 0 && options.customHeight != null && options.customHeight > 0) {
            targetWidth = options.customWidth
            targetHeight = options.customHeight
        } else if (options.resizePercentage in 1..99) {
            targetWidth = (src.width * (options.resizePercentage / 100.0)).toInt().coerceAtLeast(1)
            targetHeight = (src.height * (options.resizePercentage / 100.0)).toInt().coerceAtLeast(1)
        }

        if (targetWidth == src.width && targetHeight == src.height) {
            return src
        }

        return Bitmap.createScaledBitmap(src, targetWidth, targetHeight, true)
    }

    private fun flattenTransparency(src: Bitmap, bgColor: Int): Bitmap {
        if (!src.hasAlpha()) return src
        val result = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        canvas.drawColor(bgColor)
        canvas.drawBitmap(src, 0f, 0f, Paint(Paint.FILTER_BITMAP_FLAG))
        return result
    }

    /**
     * Pure Kotlin 24-bit RGB BMP encoder with standard Windows BITMAPFILEHEADER and BITMAPINFOHEADER.
     */
    private fun writeBmp(bitmap: Bitmap, outputStream: FileOutputStream) {
        val width = bitmap.width
        val height = bitmap.height
        val rowPadding = (4 - (width * 3) % 4) % 4
        val imageSize = (width * 3 + rowPadding) * height
        val fileSize = 54 + imageSize

        val header = ByteBuffer.allocate(54).order(ByteOrder.LITTLE_ENDIAN)
        // BITMAPFILEHEADER (14 bytes)
        header.put('B'.code.toByte())
        header.put('M'.code.toByte())
        header.putInt(fileSize)
        header.putShort(0) // reserved 1
        header.putShort(0) // reserved 2
        header.putInt(54) // offset to pixel data

        // BITMAPINFOHEADER (40 bytes)
        header.putInt(40) // header size
        header.putInt(width)
        header.putInt(height) // bottom-up bitmap
        header.putShort(1) // color planes
        header.putShort(24) // bits per pixel (RGB)
        header.putInt(0) // compression (0 = BI_RGB)
        header.putInt(imageSize)
        header.putInt(2835) // horizontal ppm (~72 DPI)
        header.putInt(2835) // vertical ppm
        header.putInt(0) // colors in color table
        header.putInt(0) // important color count

        outputStream.write(header.array())

        val pixels = IntArray(width)
        val rowBuffer = ByteArray(width * 3 + rowPadding)

        // BMP is stored bottom-up
        for (y in height - 1 downTo 0) {
            bitmap.getPixels(pixels, 0, width, 0, y, width, 1)
            var bufferIndex = 0
            for (x in 0 until width) {
                val color = pixels[x]
                // BGR format in BMP
                rowBuffer[bufferIndex++] = (color and 0xFF).toByte()
                rowBuffer[bufferIndex++] = ((color shr 8) and 0xFF).toByte()
                rowBuffer[bufferIndex++] = ((color shr 16) and 0xFF).toByte()
            }
            for (p in 0 until rowPadding) {
                rowBuffer[bufferIndex++] = 0
            }
            outputStream.write(rowBuffer, 0, bufferIndex)
        }
    }

    /**
     * Pure Kotlin ICO generator containing high-quality PNG image payload.
     */
    private fun writeIco(bitmap: Bitmap, outputStream: FileOutputStream) {
        val icoSize = 64.coerceAtMost(bitmap.width.coerceAtMost(bitmap.height))
        val scaled = Bitmap.createScaledBitmap(bitmap, icoSize, icoSize, true)

        val pngBytes = ByteArrayOutputStream().use { baos ->
            scaled.compress(Bitmap.CompressFormat.PNG, 100, baos)
            baos.toByteArray()
        }
        if (scaled != bitmap) scaled.recycle()

        val header = ByteBuffer.allocate(6 + 16).order(ByteOrder.LITTLE_ENDIAN)
        // ICONDIR (6 bytes)
        header.putShort(0) // Reserved
        header.putShort(1) // Type 1 = ICO
        header.putShort(1) // 1 image

        // ICONDIRENTRY (16 bytes)
        header.put((if (icoSize >= 256) 0 else icoSize).toByte()) // Width
        header.put((if (icoSize >= 256) 0 else icoSize).toByte()) // Height
        header.put(0.toByte()) // Palette colors (0 = no palette)
        header.put(0.toByte()) // Reserved
        header.putShort(1) // Color planes
        header.putShort(32) // Bits per pixel
        header.putInt(pngBytes.size) // Size of image data
        header.putInt(22) // Offset to image data (6 + 16 = 22)

        outputStream.write(header.array())
        outputStream.write(pngBytes)
    }
}
