package com.example.engine

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import com.example.model.ConversionOptions
import java.io.File
import java.io.FileOutputStream

object VideoConversionEngine {

    fun extractKeyframe(
        context: Context,
        inputUri: Uri,
        targetExtension: String,
        options: ConversionOptions,
        outputFile: File,
        onProgress: (Float) -> Unit
    ): File {
        onProgress(0.2f)
        val retriever = MediaMetadataRetriever()
        retriever.setDataSource(context, inputUri)

        val timeUs = options.videoKeyframeSecond * 1000000L
        val frameBitmap = retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
            ?: retriever.frameAtTime
            ?: throw IllegalStateException("Failed to extract frame from video file")

        onProgress(0.6f)
        retriever.release()

        val fos = FileOutputStream(outputFile)
        val ext = targetExtension.lowercase().trimStart('.')
        when (ext) {
            "jpg", "jpeg" -> {
                frameBitmap.compress(Bitmap.CompressFormat.JPEG, options.videoFrameQuality.coerceIn(1, 100), fos)
            }
            "png" -> {
                frameBitmap.compress(Bitmap.CompressFormat.PNG, 100, fos)
            }
            "webp" -> {
                frameBitmap.compress(Bitmap.CompressFormat.WEBP, options.videoFrameQuality.coerceIn(1, 100), fos)
            }
            else -> {
                frameBitmap.compress(Bitmap.CompressFormat.JPEG, 90, fos)
            }
        }
        fos.flush()
        fos.close()
        frameBitmap.recycle()

        onProgress(1.0f)
        return outputFile
    }

    fun extractAudioFromVideo(
        context: Context,
        inputUri: Uri,
        options: ConversionOptions,
        outputFile: File,
        onProgress: (Float) -> Unit
    ): File {
        return AudioConversionEngine.convertAudioToWav(
            context = context,
            inputUri = inputUri,
            options = options,
            outputFile = outputFile,
            onProgress = onProgress
        )
    }
}
